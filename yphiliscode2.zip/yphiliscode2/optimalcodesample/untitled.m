% This function computes the optimal control problem
% of an age-structured sir model 
clc;
clear all;
close all;
format long
test = -1;
tol = 0.05; % set tolerance for the iteration
N = 100; % number of subdevisions in time
M = 100; % number of subdevisions in age
FT = 10 ;% final time
h = FT/N; % step size
t = 0:h:FT; % t-variable mesh
aa = 0:h:FT; %a-variable mesh
s = zeros(length(aa),length(t));
ix = zeros(length(aa),length(t));
r = zeros(length(aa),length(t));
eta = zeros(length(aa),length(t)); % initialization
q = zeros(length(aa),length(t));
xi = zeros(length(aa),length(t));
lam=zeros(1,length(t));
IntSS=zeros(1,length(t));
IntI=zeros(1,length(t));
IntR=zeros(1,length(t));
IntU1=zeros(1,length(t));
IntU2=zeros(1,length(t));
IntSS2=zeros(1,length(t));
IntI2=zeros(1,length(t));
IntR2=zeros(1,length(t));
IntB=0;
u1 = zeros(length(aa),length(t));
u2 = zeros(length(aa),length(t));
k2 = @(x) 1*x*exp(-0.005*x); % defining parameters
k1 = 0.5;
beta = 0.5; 
mu = 0.5;
gamma = 0.1;
s0 = @(x) exp(-x);
ix0 = @(x) 1.5; %initial conditions for the forward system
r0 = @(x) 0.01;
A0 = 10;
A1 = 0.01;
A2 = 0.01;
B1 = 0.1;
B2 = 0.1;
U1max =1;
U2max = 1;
while (test<0)
olds = s;
oldix = ix;
oldr = r;
oldu1 =u1;
oldu2=u2;
oldq =q;
oldxi = xi;
oldeta=eta;
for j=1:M+1
a =j*h;
s(j,1) = s0(a);
ix(j,1)= ix0(a); %initialization at time level 1
r(j,1) = r0(a);
end
for j=2:M+1
IntB = IntB + beta*(s(j,1)+ix(j,1)+r(j,1))*h;
end
s(1,1) = IntB;
for n=2:N+1 %loop to solve the forward system
lamS=0;
for i = 1:M+1
a=i*h;
lamS = lamS + k2(a)*ix(i,n-1)*h;
end
lam(n-1) = lamS;
for j=2:M+1
s(j,n) = s(j-1,n-1)/(1 + (k1*lam(n-1) + mu + u1(j,n))*h);
ix(j,n) = (ix(j-1,n-1) + k1*lam(n-1)*s(j,n)*h)/(1 + ...
(mu+gamma+u2(j,n))*h); %forward computation
r(j,n) = (r(j-1,n-1) + u1(j,n)*s(j,n)*h + ...
(gamma+u2(j,n))*ix(j,n)*h)/(1 + mu*h);
end
IntB=0;
for j=2:M+1
IntB = IntB + beta*(s(j,n) + ix(j,n) + r(j,n))*h;
end
s(1,n) = IntB;
end
lamS=0;
for i = 2:M+1
a=i*h;
lamS = lamS + k2(a)*ix(i,N)*h;
end
lam(N) = lamS;
for i = 1:N
for k=1:M
n = N+2-i;
j= M+2-k;
eta(j-1,n-1) = (eta(j,n)+beta*q(1,n)*h)/(1+mu*h);
q(j-1,n-1) = (beta*q(1,n)+k1*lam(n)*xi(j-1,n)+...
u1(j-1,n-1)*eta(j-1,n-1) ... %backward ...computation
+A1*u1(j-1,n-1))/(1+(k1*lam(n)+u1(j-1,n-1)+mu)*h);
IntS = 0;
for l=2:M+1
IntS = IntS+k1*(q(l,n)+xi(l,n))*s(l,n)*h;
end
a=j*h;
Int = k2(a)* IntS;
xi(j-1,n-1) = (xi(j,n) + (beta*q(1,n)-Int + ...
(gamma+u2(j-1,n-1))*eta(j-1,n-1) + A0 + ...
A2*u2(j-1,n-1))*h)/...
(1 + (gamma + u2(j-1,n-1) + mu)*h);
end
end
for n = 1:N+1
for j = 1:M+1
u10(j,n) = min(U1max,max(0,s(j,n)*(q(j,n)-eta(j,n)-A1)/B1));
u20(j,n) = ...
min(U2max,max(0,ix(j,n)*(xi(j,n)-eta(j,n)-A2)/B2));
end
end
u1 = 0.5*(oldu1+u10);
u2 = 0.5*(oldu2+u20);
temp1 = tol*sum(abs(u1),'double')-sum(abs(oldu1-u1),'double');
temp2 = tol*sum(abs(u2),'double')-sum(abs(oldu2-u2),'double');
temp3 = tol*sum(abs(s),'double')-sum(abs(olds-s),'double');
temp4 = tol*sum(abs(ix),'double')-sum(abs(oldix-ix),'double');
temp5 = tol*sum(abs(r),'double')-sum(abs(oldr-r),'double');
temp6 = ...
tol*sum(abs(eta),'double')-sum(abs(oldeta-eta),'double');
temp7 = tol*sum(abs(q),'double')-sum(abs(oldq-q),'double');
temp8 = tol*sum(abs(xi),'double')-sum(abs(oldxi-xi),'double');
test1 = min(temp1,temp2);
test2 = min(temp3,min(temp4,temp5));
test3 = min(temp6,min(temp7,temp8));
test = min(test1,min(test2,test3));
end
for n=1:N+1
for j=2:M+1
    IntSS(n) = IntSS(n)+s(j,n)*h;
IntI(n) = IntI(n)+ix(j,n)*h;
IntR(n) = IntR(n)+r(j,n)*h;
IntU1(n) = IntU1(n)+u1(j,n)*h;
IntU2(n) = IntU2(n)+u2(j,n)*h;
end
end
%loop to solve the forward system without the control
olds2 = zeros(1,length(t));
oldix2 = zeros(1,length(t));
oldr2 = zeros(1,length(t));
s2 = zeros(1,length(t));
ix2 = zeros(1,length(t));
r2 = zeros(1,length(t));
for j=1:M+1
a =j*h;
olds2(j) = s0(a);
oldix2(j)= ix0(a); %initialization at time level 1
oldr2(j) = r0(a);
end
for n=1:N+1
lamS=0;
for i = 2:M+1
a=i*h;
lamS = lamS + k2(a)*oldix2(i)*h;
end
for j=2:M+1
s2(j) = olds2(j-1)/(1+(k1*lamS+mu)*h);
ix2(j) = (oldix2(j-1) +k1*lamS*s2(j)*h)/(1+(mu+gamma)*h); ...
%forward computation without control
r2(j) = (oldr2(j-1)+gamma*ix2(j)*h)/(1+mu*h);
end
IntB=0;
for j=2:M+1
IntB = IntB + beta*(s2(j)+ix2(j)+r2(j))*h;
end
s2(1) = IntB;
SS2 =0;
IX2 = 0;
R2 =0;
for j=2:M+1
SS2 = SS2+ s2(j)*h;
IX2 = IX2+ ix2(j)*h;
R2 = R2 + r2(j)*h;
end
IntSS2(n) = SS2;
IntI2(n) = IX2;
IntR2(n) = R2;
olds2 = s2;
oldix2 =ix2;
oldr2 = r2;
end

figure(6)
surf(u1)
view(40,30);
rotate3d on
set(gca,...
'linewidth',2,...
'fontsize',14,...
'fontweight','bold',...
'fontname','arial');
xlabel('Age','FontSize',20,'FontName','Sans-serif');
ylabel('Time','FontSize',20,'FontName','Sans-serif');
zlabel('Vaccination','FontSize',20,'FontName',...
'Sans-serif','FontWeight','normal');
set(gca,'XLim',[0 100]);
set(gca,'YLim',[0 100]);
set(gca,'XTick',[0 50 100]);
set(gca,'XTickLabel',{'0','5','10'});

set(gca,'YTick',[0 50 100]);
set(gca,'YTickLabel',{'0','5','10'});
colormap(jet)
colorbar
shading interp
figure(7)
surf(u2)
view(40,30);
rotate3d on
set(gca,...
'linewidth',2,...
'fontsize',14,...
'fontweight','bold',...
'fontname','arial');
xlabel('Age','FontSize',20,'FontName','Sans-serif');
ylabel('Time','FontSize',20,'FontName','Sans-serif');
zlabel('Treatment','FontSize',20,'FontName',...
'Sans-serif','FontWeight','normal');
set(gca,'XLim',[0 100]);
set(gca,'YLim',[0 100]);
set(gca,'XTick',[0 50 100]);
set(gca,'XTickLabel',{'0','5','10'});
set(gca,'YTick',[0 50 100]);
set(gca,'YTickLabel',{'0','5','10'});
colormap(jet)
colorbar
shading interp





