function ss = modelss(theta,data1)
%  sum-of-squares function

time   = data1(:,1);
ydata  = data1(:,2);

y0 =[123252000,theta(end),5127,2184,1700,573,48]; %ģ�ͳ�ֵ

ymodel = modelfunX(time,theta,y0);
ss = sum((ymodel- ydata).^2);
