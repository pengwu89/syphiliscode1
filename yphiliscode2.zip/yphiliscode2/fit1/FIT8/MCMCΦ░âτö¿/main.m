clc
clear

%cases1=[2127	6141	7288	8534	10191	11270	12224	12555	11563	10078	8358	6799	5260	4932	4078]';%35-39��һ��÷��
%cases1=[2184	4751	5272	5942	6834	7435	7504	7471	7232	6523	6096	5241	4307	4073	3688]';%35-39�����÷��
cases1=[2273	4787	7775	10537	13710	16433	20269	22443	22644	21881	22588	24284	26000	28679	29995]';%35-39������÷��
%cases1=[48	95	140	148	163	191	224	235	201	214	214	191	191	193	193]';%35-39��������÷��




n=length(cases1);
days=[1:1:n]';%����
data1=[days,cases1];
data2=[days,cases1];
nsimu= 20000;   % number of simulations
model.S20 = 1;
model.N0  = 4;
options.nsimu=nsimu;         % n:o of simulations

%%
% The model sum of squares in file <algaess.html |algaess.m|> is
% given in the model structure.
model.ssfun = @modelss;
k0=[0.38,0.15,0.4,0.4,0.37,0.5,0.46,0.45,9e6,5e5];
%%
% All parameters are constrained to be positive. The initial
% concentrations are also unknown and are treated as extra parameters.
params = {
    %{'\gamma_1', k0(1),  0, 1}
{'\zeta_8', k0(1),  0, 1}
{'\theta_8', k0(2),  0, 1}
    {'\xi_8', k0(3),  0, 1}
   
    {'\omega_8',  k0(4),  0, 1}
    {'\epsilon_8',  k0(5),  0, 1}
    {'\alpha_8',  k0(6),  0, 1}
     {'\beta_8',  k0(7),  0, 1}
      {'\gamma_8',  k0(8),  0, 1}
       {'\Lambda',  k0(9),  0, 10000000}
     {'E(0)',  k0(10),  0, 1000000}
    };


%%
% First generate an initial chain.

results = [];
[results, chain, s2chain,sschain]=mcmcrun(model,data1,params,options,results);


save data;

%%
% Chain plots should reveal that the chain has converged and we can
% use the results for estimation and predictive inference.
figure(1); clf
mcmcplot(chain,[],results);
figure(2); clf
mcmcplot(chain(10001:20000,:),[],results,'hist',30)
%plot(chain(10001:20000,:),'\epsilon',results,'hist',20)


figure(3); clf
mcmcplot(chain(10001:20000,:),[],results,'pairs');
figure(4); clf
mcmcplot(chain(10001:20000,:),[],results,'denspanel',2);

%%
% Function |chainstats| calculates mean ans std from the chain and
% estimates the Monte Carlo error of the estimates. Number |tau| is
% the integrated autocorrelation time and |geweke| is a simple test
% for a null hypothesis that the chain has converged.
chainstats(chain,results)

%%
% In order to use the |mcmcpred| function we need
% function |modelfun| with input arguments given as
% |modelfun(xdata,theta)|. We construct this as an anonymous function.
y0 =[123252000,17000,5127,2184,1700,573,48]; %ģ�ͳ�ֵ
%modelfun1 = @ (d,th)modelfunX(d(:,1),th,y0);
modelfun1 = @ (d,th)modelfunX(d(:,1),th([1:9]),[y0(1),th(10),y0(3),y0(4),y0(5),y0(6),y0(7)]);
%modelfun2 = @ (d,th)modelfunY(d(:,1),th,y0);
modelfun2 = @ (d,th)modelfunY(d(:,1),th([1:9]),[y0(1),th(10),y0(3),y0(4),y0(5),y0(6),y0(7)]);
%%
nsample = 10000;
out1 = mcmcpred(results,chain,[],data1,modelfun1,nsample);
out2 = mcmcpred(results,chain,[],data1,modelfun2,nsample);
figure(5); clf
mcmcpredplot(out1);
hold on
plot(data1(:,1),data1(:,2),'ro','LineWidth',6); 
axis([0.4 15.6 0 inf])
grid on
set(gca,'FontSize',30)
xlabel('Year')
ylabel('Newly secondary stage syphilis cases')




figure(6); clf
mcmcpredplot(out2);
hold on
plot(data1(:,1),cumsum(data1(:,2)),'ro', 'LineWidth',6); 
axis([0.4 15.6 0 inf])
grid on
set(gca,'FontSize',30)
xlabel('Year')
ylabel('Cumulative secondary stage syphilis cases')
