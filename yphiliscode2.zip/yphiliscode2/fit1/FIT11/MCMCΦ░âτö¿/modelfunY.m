function Y=modelfunY(time,theta,y0)
% model function

[t,x] = ode15s(@modelling,time,y0,[],theta);

Y=x(:,4)+x(:,7);