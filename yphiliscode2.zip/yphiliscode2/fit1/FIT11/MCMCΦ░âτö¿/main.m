clc
clear










%cases1=[1829	2726	3324	3970	5012	5220	5643	5887	6029	6144	6067	5824	5255	5335	4658]';%50-54��һ��÷��
%cases1=[1851	2145	2490	2842	3323	3667	3609	3617	3775	3954	4092	4217	3995	3942	3891]';%50-54�����÷��
cases1=[943	2184	3906	5588	7456	8594	10595	11849	13118	15617	18899	23397	28299	33802	36782]';%50-54������÷��
%cases1=[34	72	126	172	188	221	277	257	316	358	405	383	495	438	487]';%50-54��������÷��




n=length(cases1);
days=[1:1:n]';%����
data1=[days,cases1];
data2=[days,cases1];
nsimu= 20000;   % number of simulations
model.S20 = 1;
model.N0  = 4;
options.nsimu=nsimu;         % n:o of simulations

%%
% The model sum of squares in file <algaess.html |algaess.m|> is
% given in the model structure.
model.ssfun = @modelss;
k0=[0.142,0.284,0.4,0.68,0.69,0.5,0.6,0.4,4e6,6e5];
%%
% All parameters are constrained to be positive. The initial
% concentrations are also unknown and are treated as extra parameters.
params = {
    %{'\gamma_1', k0(1),  0, 1}
{'\zeta_{11}', k0(1),  0, 1}
{'\theta_{11}', k0(2),  0, 1}
    {'\xi_{11}', k0(3),  0, 1}
   
    {'\omega_{11}',  k0(4),  0, 1}
    {'\epsilon_{11}',  k0(5),  0, 1}
    {'\alpha_{11}',  k0(6),  0, 1}
     {'\beta_{11}',  k0(7),  0, 1}
      {'\gamma_{11}',  k0(8),  0, 1}
       {'\Lambda',  k0(9),  0, 10000000}
     {'E(0)',  k0(10),  0, 1000000}
    };


%%
% First generate an initial chain.

results = [];
[results, chain, s2chain,sschain]=mcmcrun(model,data1,params,options,results);


save data;

%%
% Chain plots should reveal that the chain has converged and we can
% use the results for estimation and predictive inference.
figure(1); clf
mcmcplot(chain,[],results);
figure(2); clf
mcmcplot(chain(10001:20000,:),[],results,'hist',30)
%plot(chain(10001:20000,:),'\epsilon',results,'hist',20)


figure(3); clf
mcmcplot(chain(10001:20000,:),[],results,'pairs');
figure(4); clf
mcmcplot(chain(10001:20000,:),[],results,'denspanel',2);

%%
% Function |chainstats| calculates mean ans std from the chain and
% estimates the Monte Carlo error of the estimates. Number |tau| is
% the integrated autocorrelation time and |geweke| is a simple test
% for a null hypothesis that the chain has converged.
chainstats(chain,results)

%%
% In order to use the |mcmcpred| function we need
% function |modelfun| with input arguments given as
% |modelfun(xdata,theta)|. We construct this as an anonymous function.
y0 =[81679000,17000,2329,943,700,243,34]; %ģ�ͳ�ֵ
%modelfun1 = @ (d,th)modelfunX(d(:,1),th,y0);
modelfun1 = @ (d,th)modelfunX(d(:,1),th([1:9]),[y0(1),th(10),y0(3),y0(4),y0(5),y0(6),y0(7)]);
%modelfun2 = @ (d,th)modelfunY(d(:,1),th,y0);
modelfun2 = @ (d,th)modelfunY(d(:,1),th([1:9]),[y0(1),th(10),y0(3),y0(4),y0(5),y0(6),y0(7)]);
%%
nsample = 10000;
out1 = mcmcpred(results,chain,[],data1,modelfun1,nsample);
out2 = mcmcpred(results,chain,[],data1,modelfun2,nsample);
figure(5); clf
mcmcpredplot(out1);
hold on
plot(data1(:,1),data1(:,2),'ro', 'LineWidth',6); 
axis([0.4 15.6 0 inf])
grid on
set(gca,'FontSize',30)
xlabel('Year')
ylabel('Newly latent stage syphilis cases')




figure(6); clf
mcmcpredplot(out2);
hold on
plot(data1(:,1),cumsum(data1(:,2)),'ro', 'LineWidth',6); 
axis([0.4 15.6 0 inf])
grid on
set(gca,'FontSize',30)
xlabel('Year')
ylabel('Cumulative latent stage syphilis cases')
