function ss = modelss(theta,data1)
%  sum-of-squares function

time   = data1(:,1);
ydata  = data1(:,2);

y0 =[91467000,theta(end),2783,2096,960,617,45]; %ģ�ͳ�ֵ

ymodel = modelfunX(time,theta,y0);
ss = sum((ymodel- ydata).^2);
