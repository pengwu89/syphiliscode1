clc
clear

%cases1=[2783	2892	3574	4256	5657	7262	7364	8361	8480	7640	7826	6842	5652	5579	4861]';%45-49��һ��÷��
%cases1=[2096	2389	2585	3067	4019	4916	5357	5732	5701	5500	5331	4938	4443	4421	4210]';%45-49�����÷��
%cases1=[1217	2499	3679	5471	8073	10976	14438	17685	19370	20188	22576	26119	29003	33535	36257]';%45-49������÷��
cases1=[45	77	107	179	170	242	315	347	388	381	380	390	386	380	389]';%45-49��������÷��




n=length(cases1);
days=[1:1:n]';%����
data1=[days,cases1];
data2=[days,cases1];
nsimu= 20000;   % number of simulations
model.S20 = 1;
model.N0  = 4;
options.nsimu=nsimu;         % n:o of simulations

%%
% The model sum of squares in file <algaess.html |algaess.m|> is
% given in the model structure.
model.ssfun = @modelss;
k0=[0.032,0.054,0.059,0.8,0.9,0.32,0.5,0.8,3.4e6,6.99e5];
%%
% All parameters are constrained to be positive. The initial
% concentrations are also unknown and are treated as extra parameters.
params = {
    %{'\gamma_1', k0(1),  0, 1}
{'\zeta_{10}', k0(1),  0, 1}
{'\theta_{10}', k0(2),  0, 1}
    {'\xi_{10}', k0(3),  0, 1}
   
    {'\omega_{10}',  k0(4),  0, 1}
    {'\epsilon_{10}',  k0(5),  0, 1}
    {'\alpha_{10}',  k0(6),  0, 1}
     {'\beta_{10}',  k0(7),  0, 1}
      {'\gamma_{10}',  k0(8),  0, 1}
       {'\Lambda',  k0(9),  0, 10000000}
     {'E(0)',  k0(10),  0, 1000000}
    };


%%
% First generate an initial chain.

results = [];
[results, chain, s2chain,sschain]=mcmcrun(model,data1,params,options,results);


save data;

%%
% Chain plots should reveal that the chain has converged and we can
% use the results for estimation and predictive inference.
figure(1); clf
mcmcplot(chain,[],results);
figure(2); clf
mcmcplot(chain(10001:20000,:),[],results,'hist',30)
%plot(chain(10001:20000,:),'\epsilon',results,'hist',20)


figure(3); clf
mcmcplot(chain(10001:20000,:),[],results,'pairs');
figure(4); clf
mcmcplot(chain(10001:20000,:),[],results,'denspanel',2);

%%
% Function |chainstats| calculates mean ans std from the chain and
% estimates the Monte Carlo error of the estimates. Number |tau| is
% the integrated autocorrelation time and |geweke| is a simple test
% for a null hypothesis that the chain has converged.
chainstats(chain,results)

%%
% In order to use the |mcmcpred| function we need
% function |modelfun| with input arguments given as
% |modelfun(xdata,theta)|. We construct this as an anonymous function.
y0 =[91467000,17000,2783,2096,960,617,45]; %ģ�ͳ�ֵ
%modelfun1 = @ (d,th)modelfunX(d(:,1),th,y0);
modelfun1 = @ (d,th)modelfunX(d(:,1),th([1:9]),[y0(1),th(10),y0(3),y0(4),y0(5),y0(6),y0(7)]);
%modelfun2 = @ (d,th)modelfunY(d(:,1),th,y0);
modelfun2 = @ (d,th)modelfunY(d(:,1),th([1:9]),[y0(1),th(10),y0(3),y0(4),y0(5),y0(6),y0(7)]);
%%
nsample = 10000;
out1 = mcmcpred(results,chain,[],data1,modelfun1,nsample);
out2 = mcmcpred(results,chain,[],data1,modelfun2,nsample);
figure(5); clf
mcmcpredplot(out1);
hold on
plot(data1(:,1),data1(:,2),'ro', 'LineWidth',6); 
axis([0.4 15.6 0 inf])
grid on
set(gca,'FontSize',30)
xlabel('Year')
ylabel('Newly secondary stage syphilis cases')




figure(6); clf
mcmcpredplot(out2);
hold on
plot(data1(:,1),cumsum(data1(:,2)),'ro', 'LineWidth',6); 
axis([0.4 15.6 0 inf])
grid on
set(gca,'FontSize',30)
xlabel('Year')
ylabel('Cumulative secondary stage syphilis cases')
