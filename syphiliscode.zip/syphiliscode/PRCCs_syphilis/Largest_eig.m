function R00=Largest_eig(KK)

%% ����
phi=1/18;%ȡ����ͬ��ֵ
delta=365/46;%ȡ����ͬ��ֵ
eta1=365/28;%ȡ����ͬ��ֵ
sigma0=365/128;
d=0.2;%ȡ����ͬ��ֵ
mu1=1/76;mu2=1/71;mu3=1/65;mu4=1/61;mu5=1/56;mu6=1/51;mu7=1/46;
mu8=1/41;mu9=1/36;mu10=1/31;mu11=1/26;mu12=1/21;mu13=1/16;mu14=1/11;
%% �ϻ���
%sigma=1/5;
sigma1=1/5;sigma2=1/5;sigma3=1/5;sigma4=1/5;sigma5=1/5;sigma6=1/5;sigma7=1/5;
sigma8=1/5;sigma9=1/5;sigma10=1/5;sigma11=1/5;sigma12=1/5; sigma13=1/5;sigma14=1/5;
%phi=6;%ȡ����ͬ��ֵ
%% ������
N0=[62977000,81127000,112240000,104716000,80596000,93892000,123497000,123252000,91467000,94314000,81679000,57472000,46023000,107246000];
Lambda=sum(N0)*mu1;

%% �޲�ƽ���
S10=Lambda/(mu1+sigma1);
S20=sigma1*S10/(mu2+sigma2);
S30=sigma2*S20/(mu3+sigma3);
S40=sigma3*S30/(mu4+sigma4);
S50=sigma4*S40/(mu5+sigma5);
S60=sigma5*S50/(mu6+sigma6);
S70=sigma6*S60/(mu7+sigma7);
S80=sigma7*S70/(mu8+sigma8);
S90=sigma8*S80/(mu9+sigma9);
S100=sigma9*S90/(mu10+sigma10);
S110=sigma10*S100/(mu11+sigma11);
S120=sigma11*S110/(mu12+sigma12);
S130=sigma12*S120/(mu13+sigma13);
S140=sigma13*S130/(mu14+sigma14);

zeta1=	KK(1);
zeta2=	KK(2);
zeta3=	KK(3);
zeta4=	KK(4);
zeta5=	KK(5);
zeta6=	KK(6);
zeta7=	KK(7);
zeta8=	KK(8);
zeta9=	KK(9);
zeta10=	KK(10);
zeta11=	KK(11);
zeta12=	KK(12);
zeta13=	KK(13);
zeta14=	KK(14);
xi1=	KK(15);
xi2=	KK(16);
xi3=	KK(17);
xi4=	KK(18);
xi5=	KK(19);
xi6=	KK(20);
xi7=	KK(21);
xi8=	KK(22);
xi9=	KK(23);
xi10=	KK(24);
xi11=	KK(25);
xi12=	KK(26);
xi13=	KK(27);
xi14=	KK(28);
omega1=	KK(29);
omega2=	KK(30);
omega3=	KK(31);
omega4=	KK(32);
omega5=	KK(33);
omega6=	KK(34);
omega7=	KK(35);
omega8=	KK(36);
omega9=	KK(37);
omega10=	KK(38);
omega11=	KK(39);
omega12=	KK(40);
omega13=	KK(41);
omega14=	KK(42);
epsilon1=	KK(43);
epsilon2=	KK(44);
epsilon3=	KK(45);
epsilon4=	KK(46);
epsilon5=	KK(47);
epsilon6=	KK(48);
epsilon7=	KK(49);
epsilon8=	KK(50);
epsilon9=	KK(51);
epsilon10=	KK(52);
epsilon11=	KK(53);
epsilon12=	KK(54);
epsilon13=	KK(55);
epsilon14=	KK(56);
alpha1=	KK(57);
alpha2=	KK(58);
alpha3=	KK(59);
alpha4=	KK(60);
alpha5=	KK(61);
alpha6=	KK(62);
alpha7=	KK(63);
alpha8=	KK(64);
alpha9=	KK(65);
alpha10=	KK(66);
alpha11=	KK(67);
alpha12=	KK(68);
alpha13=	KK(69);
alpha14=	KK(70);
beta1=	KK(71);
beta2=	KK(72);
beta3=	KK(73);
beta4=	KK(74);
beta5=	KK(75);
beta6=	KK(76);
beta7=	KK(77);
beta8=	KK(78);
beta9=	KK(79);
beta10=	KK(80);
beta11=	KK(81);
beta12=	KK(82);
beta13=	KK(83);
beta14=	KK(84);
gamma1=	KK(85);
gamma2=	KK(86);
gamma3=	KK(87);
gamma4=	KK(88);
gamma5=	KK(89);
gamma6=	KK(90);
gamma7=	KK(91);
gamma8=	KK(92);
gamma9=	KK(93);
gamma10=KK(94);
gamma11=KK(95);
gamma12=KK(96);
gamma13=KK(97);
gamma14=KK(98);



%% �Ӵ�����ÿ���������������
eta=[355.158165896884,87.3953783055927,25.7356435227571,16.3546603652087,28.7393577616292,46.5657347223002,46.8016515621509,20.9369888532573,16.4234454780435,6.39259165783302,6.82096422332789,16.4234454780435,6.39259165783302,6.82096422332789;
  68.5163988882197,179.820197628444,64.7521645053893,33.9448792709547,31.0701883081164,34.7499507504581,35.3701133869931,22.2600001876919,16.3218828022034,5.88734433894211,5.32317991528260,16.3218828022034,5.88734433894211,5.32317991528260;
   25.4490901872354,81.6743066642174,111.607740352359,55.0211666512519,49.6640195326784,44.7912228620159,34.4318589825162,29.3127007144274,25.3940975428606,9.25310038886363,6.25558294834074,25.3940975428606,9.25310038886363,6.25558294834074;
 16.8178171223902,44.5242181504875,57.2164175713329,82.7721927930597,62.9548477454476,54.9354197906575,37.1444634058768,25.2290676714027,27.1068222812073,11.4145125731629,8.52075235250833,27.1068222812073,11.4145125731629,8.52075235250833;
  24.3230303575688,33.5411884013692,42.5055128660220,51.8133538752384,97.5325033049042,66.4805150560410,41.2220361159358,24.3604747402647,20.3025677956870,11.8459992196647,11.7158606987305,20.3025677956870,11.8459992196647,11.7158606987305;
   37.2846668356735,35.4904853002655,36.2676568504283,42.7748168347990,62.8952082380579,95.6513430407290,48.2416002039840,30.8635896147088,19.6261224681018,9.51630157685224,11.0149371146536,19.6261224681018,9.51630157685224,11.0149371146536;
  44.2728850633040,42.6782923981155,32.9382019103274,34.1698158109172,46.0750124536818,56.9947093307949,66.5711641735694,34.6075453120721,20.5216958799266,8.15075064993012,9.77269224636689,20.5216958799266,8.15075064993012,9.77269224636689;
 26.5561023108486,36.0138219017784,37.5983439662063,31.1188269100358,36.5086047508490,48.8914300060903,46.4028080552528,44.6531793151312,29.2532648490479,8.92622113779601,8.46448324402757,29.2532648490479,8.92622113779601,8.46448324402757;
  20.1755442544901,25.5755615839414,31.5468892370448,32.3825838263984,29.4694026189448,30.1114509914575,26.6500230117558,28.3325208991349,43.1171958609758,14.7289307560180,10.7582708201767,43.1171958609758,14.7289307560180,10.7582708201767;
  10.8842662399927,12.7860255492603,15.9320711878524,18.8995501696831,23.8316037585340,20.2360890748572,14.6704405275470,11.9822871570676,20.4142029137555,23.2037618329382,15.3108486155625,20.4142029137555,23.2037618329382,15.3108486155625;
   6.95686435075680,6.92520838400171,6.45205888525889,8.45118504108180,14.1189155264983,14.0309145181205,10.5367176199697,6.80640993228987,8.93201102298037,9.17159424991560,24.4752769218887,8.93201102298037,9.17159424991560,24.4752769218887;
 20.1755442544901,25.5755615839414,31.5468892370448,32.3825838263984,29.4694026189448,30.1114509914575,26.6500230117558,28.3325208991349,43.1171958609758,14.7289307560180,10.7582708201767,43.1171958609758,14.7289307560180,10.7582708201767;
  10.8842662399927,12.7860255492603,15.9320711878524,18.8995501696831,23.8316037585340,20.2360890748572,14.6704405275470,11.9822871570676,20.4142029137555,23.2037618329382,15.3108486155625,20.4142029137555,23.2037618329382,15.3108486155625;
   6.95686435075680,6.92520838400171,6.45205888525889,8.45118504108180,14.1189155264983,14.0309145181205,10.5367176199697,6.80640993228987,8.93201102298037,9.17159424991560,24.4752769218887,8.93201102298037,9.17159424991560,24.4752769218887];

%eta=0.01*[1.409660734	0.686480509	0.357018319	0.242712627	0.482337253	0.737163057	0.87653289	0.835038195	0.51272059	0.289845635	0.251936429	0.247876411	0.155782069	0.101543632	0.094021104
%0.564961488	6.220656672	0.977717231	0.311718215	0.221258665	0.512952303	0.816633372	0.931888052	0.810165157	0.358500208	0.189689211	0.199838123	0.143450447	0.088835115	0.423490883
%0.227455637	1.739923887	7.654042907	0.853777193	0.375956494	0.307840328	0.464518934	0.783600937	0.975627675	0.53211902	0.232408552	0.145894482	0.08082536	0.07334173	0.436287593
%0.151085293	0.396556301	3.069894232	11.83860553	1.759959242	0.791935997	0.592447954	0.914793532	1.154841032	1.055145887	0.471461276	0.223207432	0.093076177	0.055412415	0.2322318
%0.345659387	0.282684561	0.384565043	3.187983652	5.994006588	2.288190852	1.3594544	1.240314179	1.159749388	1.391914075	0.850859126	0.494830107	0.152951438	0.058507457	0.595408545
%0.606603423	0.361461312	0.205135994	0.913487821	2.55877379	3.720258012	1.888081871	1.539968689	1.314116312	1.104547145	0.95862001	0.558575725	0.196576882	0.061523371	0.808345168
%0.657723451	1.004297984	0.705934371	0.511961989	1.185136135	1.851014714	2.759073093	1.931609531	1.475648223	1.107291518	0.77157222	0.612878697	0.254289968	0.08817313	0.784967536
%0.748033776	1.278345531	1.103152617	0.847316565	0.897123339	1.515701236	1.864462489	3.251083443	2.228974419	1.371195376	0.866422328	0.556912267	0.319926394	0.17758614	0.938510502
%0.509843919	1.019329337	1.31591633	1.560976062	1.181568269	1.353797836	1.702658367	2.084248478	3.188378101	1.775486909	1.09009508	0.464598559	0.275285385	0.1513803	1.016008123
%0.3126169	0.779069452	0.9033249	1.953390968	1.165707889	1.139248335	1.259371654	1.539044415	1.702010397	2.219038806	1.101921698	0.551807158	0.204803623	0.097038714	0.884850654
%0.27709757	0.611955803	0.837389676	1.172413768	1.024340652	1.276968953	1.122891684	1.135415445	1.532594298	1.616031724	1.488439311	0.783851708	0.236205267	0.080326019	0.922404962
%0.651590906	1.003204493	0.801941175	1.070834904	0.929663787	1.409211684	1.426676532	1.1562625	1.294618008	1.06007667	1.129654682	1.437239862	0.498188774	0.191972301	0.915967117
%0.571529997	0.582261329	0.395909391	0.567142761	0.520224599	0.723670242	0.838930044	0.945150458	0.763687671	0.609405729	0.481744393	0.670460438	0.773458728	0.304053265	0.644138169
%0.408655754	0.163296894	0.2220288	0.927135559	1.149450715	1.557744455	1.617889075	1.732245214	1.884454592	1.664137067	1.275003935	1.003613705	0.52208123	0.201721362	1.260792218];

H12=[alpha1*eta(1,1)*S10,alpha1*eta(1,2)*S10,alpha1*eta(1,3)*S10,alpha1*eta(1,4)*S10,alpha1*eta(1,5)*S10,alpha1*eta(1,6)*S10,alpha1*eta(1,7)*S10,alpha1*eta(1,8)*S10,alpha1*eta(1,9)*S10,alpha1*eta(1,10)*S10,alpha1*eta(1,11)*S10,alpha1*eta(1,12)*S10,alpha1*eta(1,13)*S10,alpha1*eta(1,14)*S10;
alpha2*eta(2,1)*S20,alpha2*eta(2,2)*S20,alpha2*eta(2,3)*S20,alpha2*eta(2,4)*S20,alpha2*eta(2,5)*S20,alpha2*eta(2,6)*S20,alpha2*eta(2,7)*S20,alpha2*eta(2,8)*S20,alpha2*eta(2,9)*S20,alpha2*eta(2,10)*S20,alpha2*eta(2,11)*S20,alpha2*eta(2,12)*S20,alpha2*eta(2,13)*S20,alpha2*eta(2,14)*S20;
alpha3*eta(3,1)*S30,alpha3*eta(3,2)*S30,alpha3*eta(3,3)*S30,alpha3*eta(3,4)*S30,alpha3*eta(3,5)*S30,alpha3*eta(3,6)*S30,alpha3*eta(3,7)*S30,alpha3*eta(3,8)*S30,alpha3*eta(3,9)*S30,alpha3*eta(3,10)*S30,alpha3*eta(3,11)*S30,alpha3*eta(3,12)*S30,alpha3*eta(3,13)*S30,alpha3*eta(3,14)*S30;
alpha4*eta(4,1)*S40,alpha4*eta(4,2)*S40,alpha4*eta(4,3)*S40,alpha4*eta(4,4)*S40,alpha4*eta(4,5)*S40,alpha4*eta(4,6)*S40,alpha4*eta(4,7)*S40,alpha4*eta(4,8)*S40,alpha4*eta(4,9)*S40,alpha4*eta(4,10)*S40,alpha4*eta(4,11)*S40,alpha4*eta(4,12)*S40,alpha4*eta(4,13)*S40,alpha4*eta(4,14)*S40;
alpha5*eta(5,1)*S50,alpha5*eta(5,2)*S50,alpha5*eta(5,3)*S50,alpha5*eta(5,4)*S50,alpha5*eta(5,5)*S50,alpha5*eta(5,6)*S50,alpha5*eta(5,7)*S50,alpha5*eta(5,8)*S50,alpha5*eta(5,9)*S50,alpha5*eta(5,10)*S50,alpha5*eta(5,11)*S50,alpha5*eta(5,12)*S50,alpha5*eta(5,13)*S50,alpha5*eta(5,14)*S50;
alpha6*eta(6,1)*S60,alpha6*eta(6,2)*S60,alpha6*eta(6,3)*S60,alpha6*eta(6,4)*S60,alpha6*eta(6,5)*S60,alpha6*eta(6,6)*S60,alpha6*eta(6,7)*S60,alpha6*eta(6,8)*S60,alpha6*eta(6,9)*S60,alpha6*eta(6,10)*S60,alpha6*eta(6,11)*S60,alpha6*eta(6,12)*S60,alpha6*eta(6,13)*S60,alpha6*eta(6,14)*S60;
alpha7*eta(7,1)*S70,alpha7*eta(7,2)*S70,alpha7*eta(7,3)*S70,alpha7*eta(7,4)*S70,alpha7*eta(7,5)*S70,alpha7*eta(7,6)*S70,alpha7*eta(7,7)*S70,alpha7*eta(7,8)*S70,alpha7*eta(7,9)*S70,alpha7*eta(7,10)*S70,alpha7*eta(7,11)*S70,alpha7*eta(7,12)*S70,alpha7*eta(7,13)*S70,alpha7*eta(7,14)*S70;
alpha8*eta(8,1)*S80,alpha8*eta(8,2)*S80,alpha8*eta(8,3)*S80,alpha8*eta(8,4)*S80,alpha8*eta(8,5)*S80,alpha8*eta(8,6)*S80,alpha8*eta(8,7)*S80,alpha8*eta(8,8)*S80,alpha8*eta(8,9)*S80,alpha8*eta(8,10)*S80,alpha8*eta(8,11)*S80,alpha8*eta(8,12)*S80,alpha8*eta(8,13)*S80,alpha8*eta(8,14)*S80;
alpha9*eta(9,1)*S90,alpha9*eta(9,2)*S90,alpha9*eta(9,3)*S90,alpha9*eta(9,4)*S90,alpha9*eta(9,5)*S90,alpha9*eta(9,6)*S90,alpha9*eta(9,7)*S90,alpha9*eta(9,8)*S90,alpha9*eta(9,9)*S90,alpha9*eta(9,10)*S90,alpha9*eta(9,11)*S90,alpha9*eta(9,12)*S90,alpha9*eta(9,13)*S90,alpha9*eta(9,14)*S90;
alpha10*eta(10,1)*S100,alpha10*eta(10,2)*S100,alpha10*eta(10,3)*S100,alpha10*eta(10,4)*S100,alpha10*eta(10,5)*S100,alpha10*eta(10,6)*S100,alpha10*eta(10,7)*S100,alpha10*eta(10,8)*S100,alpha10*eta(10,9)*S100,alpha10*eta(10,10)*S100,alpha10*eta(10,11)*S100,alpha10*eta(10,12)*S100,alpha10*eta(10,13)*S100,alpha10*eta(10,14)*S100;
alpha11*eta(11,1)*S110,alpha11*eta(11,2)*S110,alpha11*eta(11,3)*S110,alpha11*eta(11,4)*S110,alpha11*eta(11,5)*S110,alpha11*eta(11,6)*S110,alpha11*eta(11,7)*S110,alpha11*eta(11,8)*S110,alpha11*eta(11,9)*S110,alpha11*eta(11,10)*S110,alpha11*eta(11,11)*S110,alpha11*eta(11,12)*S110,alpha11*eta(11,13)*S110,alpha11*eta(11,14)*S110;
alpha12*eta(12,1)*S120,alpha12*eta(12,2)*S120,alpha12*eta(12,3)*S120,alpha12*eta(12,4)*S120,alpha12*eta(12,5)*S120,alpha12*eta(12,6)*S120,alpha12*eta(12,7)*S120,alpha12*eta(12,8)*S120,alpha12*eta(12,9)*S120,alpha12*eta(12,10)*S120,alpha12*eta(12,11)*S120,alpha12*eta(12,12)*S120,alpha12*eta(12,13)*S120,alpha12*eta(12,14)*S120;
alpha13*eta(13,1)*S130,alpha13*eta(13,2)*S130,alpha13*eta(13,3)*S130,alpha13*eta(13,4)*S130,alpha13*eta(13,5)*S130,alpha13*eta(13,6)*S130,alpha13*eta(13,7)*S130,alpha13*eta(13,8)*S130,alpha13*eta(13,9)*S130,alpha13*eta(13,10)*S130,alpha13*eta(13,11)*S130,alpha13*eta(13,12)*S130,alpha13*eta(13,13)*S130,alpha13*eta(13,14)*S130;
alpha14*eta(14,1)*S140,alpha14*eta(14,2)*S140,alpha14*eta(14,3)*S140,alpha14*eta(14,4)*S140,alpha14*eta(14,5)*S140,alpha14*eta(14,6)*S10,alpha1*eta(14,7)*S140,alpha14*eta(14,8)*S140,alpha14*eta(14,9)*S140,alpha14*eta(14,10)*S140,alpha14*eta(14,11)*S140,alpha14*eta(14,12)*S140,alpha14*eta(14,13)*S140,alpha14*eta(14,14)*S140];


               

H13= [beta1*eta(1,1)*S10,beta1*eta(1,2)*S10,beta1*eta(1,3)*S10,beta1*eta(1,4)*S10,beta1*eta(1,5)*S10,beta1*eta(1,6)*S10,beta1*eta(1,7)*S10,beta1*eta(1,8)*S10,beta1*eta(1,9)*S10,beta1*eta(1,10)*S10,beta1*eta(1,11)*S10,beta1*eta(1,12)*S10,beta1*eta(1,13)*S10,beta1*eta(1,14)*S10;
beta2*eta(2,1)*S20,beta2*eta(2,2)*S20,beta2*eta(2,3)*S20,beta2*eta(2,4)*S20,beta2*eta(2,5)*S20,beta2*eta(2,6)*S20,alpha2*eta(2,7)*S20,beta2*eta(2,8)*S20,beta2*eta(2,9)*S20,beta2*eta(2,10)*S20,beta2*eta(2,11)*S20,beta2*eta(2,12)*S20,beta2*eta(2,13)*S20,beta2*eta(2,14)*S20;
beta3*eta(3,1)*S30,beta3*eta(3,2)*S30,beta3*eta(3,3)*S30,beta3*eta(3,4)*S30,beta3*eta(3,5)*S30,beta3*eta(3,6)*S30,alpha3*eta(3,7)*S30,beta3*eta(3,8)*S30,beta3*eta(3,9)*S30,beta3*eta(3,10)*S30,beta3*eta(3,11)*S30,beta3*eta(3,12)*S30,beta3*eta(3,13)*S30,beta3*eta(3,14)*S30;
beta4*eta(4,1)*S40,beta4*eta(4,2)*S40,beta4*eta(4,3)*S40,beta4*eta(4,4)*S40,beta4*eta(4,5)*S40,beta4*eta(4,6)*S40,alpha4*eta(4,7)*S40,beta4*eta(4,8)*S40,beta4*eta(4,9)*S40,beta4*eta(4,10)*S40,beta4*eta(4,11)*S40,beta4*eta(4,12)*S40,beta4*eta(4,13)*S40,beta4*eta(4,14)*S40;
beta5*eta(5,1)*S50,beta5*eta(5,2)*S50,beta5*eta(5,3)*S50,beta5*eta(5,4)*S50,beta5*eta(5,5)*S50,beta5*eta(5,6)*S50,alpha5*eta(5,7)*S50,beta5*eta(5,8)*S50,beta5*eta(5,9)*S50,beta5*eta(5,10)*S50,beta5*eta(5,11)*S50,beta5*eta(5,12)*S50,beta5*eta(5,13)*S50,beta5*eta(5,14)*S50;
beta6*eta(6,1)*S60,beta6*eta(6,2)*S60,beta6*eta(6,3)*S60,beta6*eta(6,4)*S60,beta6*eta(6,5)*S60,beta6*eta(6,6)*S60,alpha6*eta(6,7)*S60,beta6*eta(6,8)*S60,beta6*eta(6,9)*S60,beta6*eta(6,10)*S60,beta6*eta(6,11)*S60,beta6*eta(6,12)*S60,beta6*eta(6,13)*S60,beta6*eta(6,14)*S60;
beta7*eta(7,1)*S70,beta7*eta(7,2)*S70,beta7*eta(7,3)*S70,beta7*eta(7,4)*S70,beta7*eta(7,5)*S70,beta7*eta(7,6)*S70,alpha7*eta(7,7)*S70,beta7*eta(7,8)*S70,beta7*eta(7,9)*S70,beta7*eta(7,10)*S70,beta7*eta(7,11)*S70,beta7*eta(7,12)*S70,beta7*eta(7,13)*S70,beta7*eta(7,14)*S70;
beta8*eta(8,1)*S80,beta8*eta(8,2)*S80,beta8*eta(8,3)*S80,beta8*eta(8,4)*S80,beta8*eta(8,5)*S80,beta8*eta(8,6)*S80,alpha8*eta(8,7)*S80,beta8*eta(8,8)*S80,beta8*eta(8,9)*S80,beta8*eta(8,10)*S80,beta8*eta(8,11)*S80,beta8*eta(8,12)*S80,beta8*eta(8,13)*S80,beta8*eta(8,14)*S80;
beta9*eta(9,1)*S90,beta9*eta(9,2)*S90,beta9*eta(9,3)*S90,beta9*eta(9,4)*S90,beta9*eta(9,5)*S90,beta9*eta(9,6)*S90,alpha9*eta(9,7)*S90,beta9*eta(9,8)*S90,beta9*eta(9,9)*S90,beta9*eta(9,10)*S90,beta9*eta(9,11)*S90,beta9*eta(9,12)*S90,beta9*eta(9,13)*S90,beta9*eta(9,14)*S90;
beta10*eta(10,1)*S100,beta10*eta(10,2)*S100,beta10*eta(10,3)*S100,beta10*eta(10,4)*S100,beta10*eta(10,5)*S100,beta10*eta(10,6)*S100,beta10*eta(10,7)*S100,beta10*eta(10,8)*S100,beta10*eta(10,9)*S100,beta10*eta(10,10)*S100,beta10*eta(10,11)*S100,beta10*eta(10,12)*S100,beta10*eta(10,13)*S100,beta10*eta(10,14)*S100;
beta11*eta(11,1)*S110,beta11*eta(11,2)*S110,beta11*eta(11,3)*S110,beta11*eta(11,4)*S110,beta11*eta(11,5)*S110,beta11*eta(11,6)*S110,beta11*eta(11,7)*S110,beta11*eta(11,8)*S110,beta11*eta(11,9)*S110,beta11*eta(11,10)*S110,beta11*eta(11,11)*S110,beta11*eta(11,12)*S110,beta11*eta(11,13)*S110,beta11*eta(11,14)*S110;
beta12*eta(12,1)*S120,beta12*eta(12,2)*S120,beta12*eta(12,3)*S120,beta12*eta(12,4)*S120,beta12*eta(12,5)*S120,beta12*eta(12,6)*S120,beta12*eta(12,7)*S120,beta12*eta(12,8)*S120,beta12*eta(12,9)*S120,beta12*eta(12,10)*S120,beta12*eta(12,11)*S120,beta12*eta(12,12)*S120,beta12*eta(12,13)*S120,beta12*eta(12,14)*S120;
beta13*eta(13,1)*S130,beta13*eta(13,2)*S130,beta13*eta(13,3)*S130,beta13*eta(13,4)*S130,beta13*eta(13,5)*S130,beta13*eta(13,6)*S130,beta13*eta(13,7)*S130,beta13*eta(13,8)*S130,beta13*eta(13,9)*S130,beta13*eta(13,10)*S130,beta13*eta(13,11)*S130,beta13*eta(13,12)*S130,beta13*eta(13,13)*S130,beta13*eta(13,14)*S130;
beta14*eta(14,1)*S140,beta14*eta(14,2)*S140,beta14*eta(14,3)*S140,beta14*eta(14,4)*S140,beta14*eta(14,5)*S140,beta14*eta(14,6)*S140,beta14*eta(14,7)*S140,beta14*eta(14,8)*S140,beta14*eta(14,9)*S140,beta14*eta(14,10)*S140,beta14*eta(14,11)*S140,beta14*eta(14,12)*S140,beta14*eta(14,13)*S140,beta14*eta(14,14)*S140];

H14=[gamma1*eta(1,1)*S10,gamma1*eta(1,2)*S10,gamma1*eta(1,3)*S10,gamma1*eta(1,4)*S10,gamma1*eta(1,5)*S10,gamma1*eta(1,6)*S10,gamma1*eta(1,7)*S10,gamma1*eta(1,8)*S10,gamma1*eta(1,9)*S10,gamma1*eta(1,10)*S10,gamma1*eta(1,11)*S10,gamma1*eta(1,12)*S10,gamma1*eta(1,13)*S10,gamma1*eta(1,14)*S10;
gamma2*eta(2,1)*S20,gamma2*eta(2,2)*S20,gamma2*eta(2,3)*S20,gamma2*eta(2,4)*S20,gamma2*eta(2,5)*S20,gamma2*eta(2,6)*S20,gamma2*eta(2,7)*S20,gamma2*eta(2,8)*S20,gamma2*eta(2,9)*S20,gamma2*eta(2,10)*S20,gamma2*eta(2,11)*S20,gamma2*eta(2,12)*S20,gamma2*eta(2,13)*S20,gamma2*eta(2,14)*S20;
gamma3*eta(3,1)*S30,gamma3*eta(3,2)*S30,gamma3*eta(3,3)*S30,gamma3*eta(3,4)*S30,gamma3*eta(3,5)*S30,gamma3*eta(3,6)*S30,gamma3*eta(3,7)*S30,gamma3*eta(3,8)*S30,gamma3*eta(3,9)*S30,gamma3*eta(3,10)*S30,gamma3*eta(3,11)*S30,gamma3*eta(3,12)*S30,gamma3*eta(3,13)*S30,gamma3*eta(3,14)*S30;
gamma4*eta(4,1)*S40,gamma4*eta(4,2)*S40,gamma4*eta(4,3)*S40,gamma4*eta(4,4)*S40,gamma4*eta(4,5)*S40,gamma4*eta(4,6)*S40,gamma4*eta(4,7)*S40,gamma4*eta(4,8)*S40,gamma4*eta(4,9)*S40,gamma4*eta(4,10)*S40,gamma4*eta(4,11)*S40,gamma4*eta(4,12)*S40,gamma4*eta(4,13)*S40,gamma4*eta(4,14)*S40;
gamma5*eta(5,1)*S50,gamma5*eta(5,2)*S50,gamma5*eta(5,3)*S50,gamma5*eta(5,4)*S50,gamma5*eta(5,5)*S50,gamma5*eta(5,6)*S50,gamma5*eta(5,7)*S50,gamma5*eta(5,8)*S50,gamma5*eta(5,9)*S50,gamma5*eta(5,10)*S50,gamma5*eta(5,11)*S50,gamma5*eta(5,12)*S50,gamma5*eta(5,13)*S50,gamma5*eta(5,14)*S50;
gamma6*eta(6,1)*S60,gamma6*eta(6,2)*S60,gamma6*eta(6,3)*S60,gamma6*eta(6,4)*S60,gamma6*eta(6,5)*S60,gamma6*eta(6,6)*S60,gamma6*eta(6,7)*S60,gamma6*eta(6,8)*S60,gamma6*eta(6,9)*S60,gamma6*eta(6,10)*S60,gamma6*eta(6,11)*S60,gamma6*eta(6,12)*S60,gamma6*eta(6,13)*S60,gamma6*eta(6,14)*S60;
gamma7*eta(7,1)*S70,gamma7*eta(7,2)*S70,gamma7*eta(7,3)*S70,gamma7*eta(7,4)*S70,gamma7*eta(7,5)*S70,gamma7*eta(7,6)*S70,gamma7*eta(7,7)*S70,gamma7*eta(7,8)*S70,gamma7*eta(7,9)*S70,gamma7*eta(7,10)*S70,gamma7*eta(7,11)*S70,gamma7*eta(7,12)*S70,gamma7*eta(7,13)*S70,gamma7*eta(7,14)*S70;
gamma8*eta(8,1)*S80,gamma8*eta(8,2)*S80,gamma8*eta(8,3)*S80,gamma8*eta(8,4)*S80,gamma8*eta(8,5)*S80,gamma8*eta(8,6)*S80,gamma8*eta(8,7)*S80,gamma8*eta(8,8)*S80,gamma8*eta(8,9)*S80,gamma8*eta(8,10)*S80,gamma8*eta(8,11)*S80,gamma8*eta(8,12)*S80,gamma8*eta(8,13)*S80,gamma8*eta(8,14)*S80;
gamma9*eta(9,1)*S90,gamma9*eta(9,2)*S90,gamma9*eta(9,3)*S90,gamma9*eta(9,4)*S90,gamma9*eta(9,5)*S90,gamma9*eta(9,6)*S90,gamma9*eta(9,7)*S90,gamma9*eta(9,8)*S90,gamma9*eta(9,9)*S90,gamma9*eta(9,10)*S90,gamma9*eta(9,11)*S90,gamma9*eta(9,12)*S90,gamma9*eta(9,13)*S90,gamma9*eta(9,14)*S90;
gamma10*eta(10,1)*S100,gamma10*eta(10,2)*S100,gamma10*eta(10,3)*S100,gamma10*eta(10,4)*S100,gamma10*eta(10,5)*S100,gamma10*eta(10,6)*S100,gamma10*eta(10,7)*S100,gamma10*eta(10,8)*S100,gamma10*eta(10,9)*S100,gamma10*eta(10,10)*S100,gamma10*eta(10,11)*S100,gamma10*eta(10,12)*S100,gamma10*eta(10,13)*S100,gamma10*eta(10,14)*S100;
gamma11*eta(11,1)*S110,gamma11*eta(11,2)*S110,gamma11*eta(11,3)*S110,gamma11*eta(11,4)*S110,gamma11*eta(11,5)*S110,gamma11*eta(11,6)*S110,gamma11*eta(11,7)*S110,gamma11*eta(11,8)*S110,gamma11*eta(11,9)*S110,gamma11*eta(11,10)*S110,gamma11*eta(11,11)*S110,gamma11*eta(11,12)*S110,gamma11*eta(11,13)*S110,gamma11*eta(11,14)*S110;
gamma12*eta(12,1)*S120,gamma12*eta(12,2)*S120,gamma12*eta(12,3)*S120,gamma12*eta(12,4)*S120,gamma12*eta(12,5)*S120,gamma12*eta(12,6)*S120,gamma12*eta(12,7)*S120,gamma12*eta(12,8)*S120,gamma12*eta(12,9)*S120,gamma12*eta(12,10)*S120,gamma12*eta(12,11)*S120,gamma12*eta(12,12)*S120,gamma12*eta(12,13)*S120,gamma12*eta(12,14)*S120;
gamma13*eta(13,1)*S130,gamma13*eta(13,2)*S130,gamma13*eta(13,3)*S130,gamma13*eta(13,4)*S130,gamma13*eta(13,5)*S130,gamma13*eta(13,6)*S130,gamma13*eta(13,7)*S130,gamma13*eta(13,8)*S130,gamma13*eta(13,9)*S130,gamma13*eta(13,10)*S130,gamma13*eta(13,11)*S130,gamma13*eta(13,12)*S130,gamma13*eta(13,13)*S130,gamma13*eta(13,14)*S130;
gamma14*eta(14,1)*S140,gamma14*eta(14,2)*S140,gamma14*eta(14,3)*S140,gamma14*eta(14,4)*S140,gamma14*eta(14,5)*S140,gamma14*eta(14,6)*S140,gamma14*eta(14,7)*S140,gamma14*eta(14,8)*S140,gamma14*eta(14,9)*S140,gamma14*eta(14,10)*S140,gamma14*eta(14,11)*S140,gamma14*eta(14,12)*S140,gamma14*eta(14,13)*S140,gamma14*eta(14,14)*S140];

                
V11=diag([mu1+delta,mu2+delta,mu3+delta,mu4+delta,mu5+delta,mu6+delta,mu7+delta,mu8+delta,mu9+delta,mu10+delta,mu11+delta,mu12+delta,mu13+delta,mu14+delta]);
 %V11=diag([]);
 V21=diag([-delta,-delta,-delta,-delta,-delta,-delta,-delta,-delta,-delta,-delta,-delta,-delta,-delta,-delta]);
 V22=diag([mu1+sigma0,mu2+sigma0,mu3+sigma0,mu4+sigma0,mu5+sigma0,mu6+sigma0,mu7+sigma0,mu8+sigma0,mu9+sigma0,mu10+sigma0,mu11+sigma0,mu12+sigma0,mu13+sigma0,mu14+sigma0]);
 V33=diag([mu1+xi1+eta1,mu2+xi2+eta1,mu3+xi3+eta1,mu4+xi4+eta1,mu5+xi5+eta1,mu6+xi6+eta1,mu7+xi7+eta1,mu8+xi8+eta1,mu9+xi9+eta1,mu10+xi10+eta1,mu11+xi11+eta1,mu12+xi12+eta1,mu13+xi13+eta1,mu14+xi14+eta1]);
 V24=-diag([(1-epsilon1)*omega1,(1-epsilon2)*omega2,(1-epsilon3)*omega3,(1-epsilon4)*omega4,(1-epsilon5)*omega5,(1-epsilon6)*omega6,(1-epsilon7)*omega7,(1-epsilon8)*omega8,(1-epsilon9)*omega9,(1-epsilon10)*omega10,(1-epsilon11)*omega11,(1-epsilon12)*omega12,(1-epsilon13)*omega13,(1-epsilon14)*omega14]);
 V34=-diag([(epsilon1)*omega1,(epsilon2)*omega2,(epsilon3)*omega3,(epsilon4)*omega4,(epsilon5)*omega5,(epsilon6)*omega6,(epsilon7)*omega7,(epsilon8)*omega8,(epsilon9)*omega9,(epsilon10)*omega10,(epsilon11)*omega11,(epsilon12)*omega12,(epsilon13)*omega13,(epsilon14)*omega14]);
 V32=diag([-sigma0,-sigma0,-sigma0,-sigma0,-sigma0,-sigma0,-sigma0,-sigma0,-sigma0,-sigma0,-sigma0,-sigma0,-sigma0,-sigma0]);
 V43=diag([-eta1,-eta1,-eta1,-eta1,-eta1,-eta1,-eta1,-eta1,-eta1,-eta1,-eta1,-eta1,-eta1,-eta1]);
 V44=diag([mu1+omega1+zeta1,mu2+omega2+zeta2,mu3+omega3+zeta3,mu4+omega4+zeta4,mu5+omega5+zeta5,mu6+omega6+zeta6,mu7+omega7+zeta7,mu8+omega8+zeta8,mu9+omega9+zeta9,mu10+omega10+zeta10,mu11+omega11+zeta11,mu12+omega12+zeta12,mu13+omega13+zeta13,mu14+omega14+zeta14]);
 
%V21=[-phi,0,0,0,0,0,0,0,0,0,0;
 %    0,-phi,0,0,0,0,0,0,0,0,0;
 %    0,0,-phi,0,0,0,0,0,0,0,0;
 %    0,0,0,-phi,0,0,0,0,0,0,0;
 %    0,0,0,0,-phi,0,0,0,0,0,0;
  %   0,0,0,0,0,-phi,0,0,0,0,0;
 %    0,0,0,0,0,0,-phi,0,0,0,0;
 %    0,0,0,0,0,0,0,-phi,0,0,0;
 %    0,0,0,0,0,0,0,0,-phi,0,0;
 %    0,0,0,0,0,0,0,0,0,-phi,0;
  %   0,0,0,0,0,0,0,0,0,0,-phi
  %   ];
 

HV=zeros(14,14);

F=[HV,H12,H13,H14;
    HV,HV,HV,HV;
    HV,HV,HV,HV;
    HV,HV,HV,HV];
V=[V11,HV,HV,HV;
    V21,V22,HV,V24;
    HV,V32,V33,V34;
    HV,HV,V43,V44];

%% ����
V_inv=inv(V);

%% �������ֵ
R00=max(eig(F*V_inv));


