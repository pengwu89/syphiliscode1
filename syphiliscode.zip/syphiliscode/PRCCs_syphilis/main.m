clc;
clear;
%% ��������
runs=2000;
%% ���ò�����ֵ����׼���ǩ
[Par_mean_std,Par_label]=xlsread('par_mean_std1.xlsx');
%% ��ֵ
mean_par=Par_mean_std(1:end,1);
%% ��׼��
mean_std=Par_mean_std(1:end,2);
%% ��������̫���γ�LHS����
for i=1:length(mean_par)
    Par_LHS(:,i)=LHS_Call([],mean_par(i),[],mean_std(i),runs,'norm');
end

%% �޳������滻С��0��ֵ
for i=1:length(mean_par)
    for j=1:runs
        if Par_LHS(j,i)<0
            Par_LHS(j,i)=mean_par(i);
        end
    end
end 

%% ������ǩ
PRCC_var=Par_label(1:end);

%% ����R0
for j=1:runs
    R0(:,j)=Largest_eig(Par_LHS(j,:));
end

%% ����PRCC
y_var='PRCCs for R_{0}';
alpha1=0.05;
[prcc sign sign_label]=PRCC(Par_LHS,R0,1,PRCC_var,alpha1,y_var);
figure(1)
K=0:1:15;
for j=1:16
C(j)=0.4; 
end
for j=1:16
C1(j)=0.2; 
end
H_F0=fill([K,fliplr(K)],[-C1,fliplr(C1)],[1 0.93725 0.85882]);
set(H_F0,{'LineStyle'},{'none'});
hold on
H_F1=fill([K,fliplr(K)],[C1,fliplr(C)],[1 0.8549 0.72549]);
set(H_F1,{'LineStyle'},{'none'});
hold on
H_F2=fill([K,fliplr(K)],[-C1,fliplr(-C)],[1 0.8549 0.72549]);
set(H_F2,{'LineStyle'},{'none'});
hold on
plot([0 15],[0 0],'k')
hold on
bar(prcc(1:14),0.6,'FaceColor',[1 0.27059 0],'EdgeColor',[1 0.27059 0])
set(gca,'ytick',[-1 -0.8 -0.6 -0.4 -0.2 0 0.2 0.4 0.6 0.8 1]);
set(gca,'yticklabel',{'-1','-0.8','-0.6','-0.4','-0.2','0','0.2','0.4','0.6','0.8','1'});
set(gca,'xtick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14]);
set(gca,'xticklabel',{PRCC_var{1:14}});
ylabel(y_var)
axis([0.3 14.7 -1 1]); 
set(gca,'FontSize',20)

figure(2)
H_F0=fill([K,fliplr(K)],[-C1,fliplr(C1)],[1 0.93725 0.85882]);
set(H_F0,{'LineStyle'},{'none'});
hold on
H_F1=fill([K,fliplr(K)],[C1,fliplr(C)],[1 0.8549 0.72549]);
set(H_F1,{'LineStyle'},{'none'});
hold on
H_F2=fill([K,fliplr(K)],[-C1,fliplr(-C)],[1 0.8549 0.72549]);
set(H_F2,{'LineStyle'},{'none'});
hold on
plot([0 15],[0 0],'k')
hold on
bar(prcc(15:28),0.6,'FaceColor',[1 0.27059 0],'EdgeColor',[1 0.27059 0])
set(gca,'ytick',[-1 -0.8 -0.6 -0.4 -0.2 0 0.2 0.4 0.6 0.8 1]);
set(gca,'yticklabel',{'-1','-0.8','-0.6','-0.4','-0.2','0','0.2','0.4','0.6','0.8','1'});
set(gca,'xtick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14]);
set(gca,'xticklabel',{PRCC_var{15:28}});
ylabel(y_var)
axis([0.3 14.7 -1 1]); 
set(gca,'FontSize',20)

figure(3)
H_F0=fill([K,fliplr(K)],[-C1,fliplr(C1)],[1 0.93725 0.85882]);
set(H_F0,{'LineStyle'},{'none'});
hold on
H_F1=fill([K,fliplr(K)],[C1,fliplr(C)],[1 0.8549 0.72549]);
set(H_F1,{'LineStyle'},{'none'});
hold on
H_F2=fill([K,fliplr(K)],[-C1,fliplr(-C)],[1 0.8549 0.72549]);
set(H_F2,{'LineStyle'},{'none'});
hold on
plot([0 15],[0 0],'k')
hold on
bar(prcc(29:42),0.6,'FaceColor',[1 0.27059 0],'EdgeColor',[1 0.27059 0])
set(gca,'ytick',[-1 -0.8 -0.6 -0.4 -0.2 0 0.2 0.4 0.6 0.8 1]);
set(gca,'yticklabel',{'-1','-0.8','-0.6','-0.4','-0.2','0','0.2','0.4','0.6','0.8','1'});
set(gca,'xtick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14]);
set(gca,'xticklabel',{PRCC_var{29:42}});
ylabel(y_var)
axis([0.3 14.7 -1 1]); 
set(gca,'FontSize',20)


figure(4)
H_F0=fill([K,fliplr(K)],[-C1,fliplr(C1)],[1 0.93725 0.85882]);
set(H_F0,{'LineStyle'},{'none'});
hold on
H_F1=fill([K,fliplr(K)],[C1,fliplr(C)],[1 0.8549 0.72549]);
set(H_F1,{'LineStyle'},{'none'});
hold on
H_F2=fill([K,fliplr(K)],[-C1,fliplr(-C)],[1 0.8549 0.72549]);
set(H_F2,{'LineStyle'},{'none'});
hold on
plot([0 15],[0 0],'k')
hold on
bar(prcc(43:56),0.6,'FaceColor',[1 0.27059 0],'EdgeColor',[1 0.27059 0])
set(gca,'ytick',[-1 -0.8 -0.6 -0.4 -0.2 0 0.2 0.4 0.6 0.8 1]);
set(gca,'yticklabel',{'-1','-0.8','-0.6','-0.4','-0.2','0','0.2','0.4','0.6','0.8','1'});
set(gca,'xtick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14]);
set(gca,'xticklabel',{PRCC_var{43:56}});
ylabel(y_var)
axis([0.3 14.7 -1 1]); 
set(gca,'FontSize',20)



figure(5)
H_F0=fill([K,fliplr(K)],[-C1,fliplr(C1)],[1 0.93725 0.85882]);
set(H_F0,{'LineStyle'},{'none'});
hold on
H_F1=fill([K,fliplr(K)],[C1,fliplr(C)],[1 0.8549 0.72549]);
set(H_F1,{'LineStyle'},{'none'});
hold on
H_F2=fill([K,fliplr(K)],[-C1,fliplr(-C)],[1 0.8549 0.72549]);
set(H_F2,{'LineStyle'},{'none'});
hold on
plot([0 15],[0 0],'k')
hold on
bar(prcc(57:70),0.6,'FaceColor',[1 0.27059 0],'EdgeColor',[1 0.27059 0])
set(gca,'ytick',[-1 -0.8 -0.6 -0.4 -0.2 0 0.2 0.4 0.6 0.8 1]);
set(gca,'yticklabel',{'-1','-0.8','-0.6','-0.4','-0.2','0','0.2','0.4','0.6','0.8','1'});
set(gca,'xtick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14]);
set(gca,'xticklabel',{PRCC_var{57:70}});
ylabel(y_var)
axis([0.3 14.7 -1 1]); 
set(gca,'FontSize',20)



figure(6)
H_F0=fill([K,fliplr(K)],[-C1,fliplr(C1)],[1 0.93725 0.85882]);
set(H_F0,{'LineStyle'},{'none'});
hold on
H_F1=fill([K,fliplr(K)],[C1,fliplr(C)],[1 0.8549 0.72549]);
set(H_F1,{'LineStyle'},{'none'});
hold on
H_F2=fill([K,fliplr(K)],[-C1,fliplr(-C)],[1 0.8549 0.72549]);
set(H_F2,{'LineStyle'},{'none'});
hold on
plot([0 15],[0 0],'k')
hold on
bar(prcc(71:84),0.6,'FaceColor',[1 0.27059 0],'EdgeColor',[1 0.27059 0])
set(gca,'ytick',[-1 -0.8 -0.6 -0.4 -0.2 0 0.2 0.4 0.6 0.8 1]);
set(gca,'yticklabel',{'-1','-0.8','-0.6','-0.4','-0.2','0','0.2','0.4','0.6','0.8','1'});
set(gca,'xtick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14]);
set(gca,'xticklabel',{PRCC_var{71:84}});
ylabel(y_var)
axis([0.3 14.7 -1 1]); 
set(gca,'FontSize',20)


figure(7)
H_F0=fill([K,fliplr(K)],[-C1,fliplr(C1)],[1 0.93725 0.85882]);
set(H_F0,{'LineStyle'},{'none'});
hold on
H_F1=fill([K,fliplr(K)],[C1,fliplr(C)],[1 0.8549 0.72549]);
set(H_F1,{'LineStyle'},{'none'});
hold on
H_F2=fill([K,fliplr(K)],[-C1,fliplr(-C)],[1 0.8549 0.72549]);
set(H_F2,{'LineStyle'},{'none'});
hold on
plot([0 15],[0 0],'k')
hold on
bar(prcc(85:98),0.6,'FaceColor',[1 0.27059 0],'EdgeColor',[1 0.27059 0])
set(gca,'ytick',[-1 -0.8 -0.6 -0.4 -0.2 0 0.2 0.4 0.6 0.8 1]);
set(gca,'yticklabel',{'-1','-0.8','-0.6','-0.4','-0.2','0','0.2','0.4','0.6','0.8','1'});
set(gca,'xtick',[1 2 3 4 5 6 7 8 9 10 11 12 13 14]);
set(gca,'xticklabel',{PRCC_var{85:98}});
ylabel(y_var)
axis([0.3 14.7 -1 1]); 
set(gca,'FontSize',20)


