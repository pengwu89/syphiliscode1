


function  age_structure1(T)
%----------------ϵͳ����---------------------------------------------------
T=100;
dt=0.1;
n=T/dt;
da=0.2;
m=10/da;

xi='-1.5820+0.6755*exp(0.1285*x)+1.2677*exp(-0.1285*x)';
%mu='0.0191';
xi=inline(xi);
%d='0.1458+1.307e-5*exp(0.1446*x)-0.3653*exp(-0.1446*x)';
zeta='0.1886+1.8520e-3*exp(0.7822*x)+0.4779*exp(-0.7822*x)';
zeta=inline(zeta);


epsilon='0.5667-2.4986e-4*exp(0.06528*x)-0.08486*exp(-0.06528*x)';
epsilon=inline(epsilon);

alpha='6.993e-6-2.5947e-6*exp(5.7942e-3*x)-4.3191e-6*exp(-5.7942e-3*x)';
alpha=inline(alpha);




gamma='7.7584e-6-2.3581e-6*exp(0.01224*x)-6.4612e-6*exp(-0.1224*x)';
gamma=inline(gamma);


beta='1.9871e-5-2.7075e-6*exp(2.5901e-2*x)-1.7791e-5*exp(-2.5901e-2*x)';
beta=inline(beta);

mu1=2.45e-3;
mu2=2.45e-2;
mu3=2.05e-2;
mu4=2.05e-2;
mu5=1.05e-3;
mu6=1.05e-3;
mu7=2e-1;

sigma=1/10;
omega=1/28;
eta=1/40;%40,10
theta=1/36;%36,6
d=3.1e-1;%3.1e-1
Lambda=4.5e6;
delta=0.019;
IntI1=zeros(1,n);
IntI2=zeros(1,n);
IntI3=zeros(1,n);
IntL=zeros(1,n);


%-----------------------��ֵ����-------------------------------------------
S(1)=1e6;
for j=1:m+1
    %s(1,j)=4e4;
    E(1,j)=500000;
  I1(1,j)=40188;
  I2(1,j)=30527;
  L1(1,j)=12000;
  L2(1,j)=6884;
  I3(1,j)=523;
end
%--------------------ϵͳ��ɢ��---------------------------------------------
for i=1:n
      for p=2:m
        Inte1(p)=alpha((p-1)*da)*I1(i,p);
        Inte2(p)=beta((p-1)*da)*I2(i,p);
        Inte3(p)=gamma((p-1)*da)*L1(i,p);
        
        
       Inte4(p)=E(i,p);
       
       Inte5(p)=(1-epsilon((p-1)*da))*L1(i,p);
       
       Inte6(p)=epsilon((p-1)*da)*L1(i,p);
       
       Inte7(p)=I1(i,p);
       
        Inte8(p)=I2(i,p);
        Inte9(p)=zeta((p-1)*da)*L1(i,p);
        
         Inte10(p)=L2(i,p);
        Inte11(p)=xi((p-1)*da)*I2(i,p);
        
      end
    D_1=(dt/2)*(alpha(0*da)*I1(i,1)+2*sum(Inte1)+alpha(m*da)*I1(i,m+1)); 
    D_2=(dt/2)*(beta(0*da)*I2(i,1)+2*sum(Inte2)+beta(m*da)*I2(i,m+1)); 
    D_3=(dt/2)*(gamma(0*da)*L1(i,1)+2*sum(Inte3)+gamma(m*da)*L1(i,m+1));
     D_4=(dt/2)*(E(i,1)+2*sum(Inte4)+E(i,m+1));
     D_5=(dt/2)*((1-epsilon(0*da))*L1(i,1)+2*sum(Inte5)+(1-epsilon(m*da))*L1(i,m+1));
     
     
     
     
    D_6=(dt/2)*(epsilon(0*da)*L1(i,1)+2*sum(Inte6)+epsilon(m*da)*L1(i,m+1));
    
    D_7=(dt/2)*(I1(i,1)+2*sum(Inte7)+I1(i,m+1)); 
    
    D_8=(dt/2)*(I2(i,1)+2*sum(Inte8)+I2(i,m+1));
     D_9=(dt/2)*(zeta(0*da)*L1(i,1)+2*sum(Inte8)+zeta(m*da)*L1(i,m+1));
    
     
      D_10=(dt/2)*(L2(i,1)+2*sum(Inte8)+L2(i,m+1));
      D_11=(dt/2)*(xi(0*da)*I2(i,1)+2*sum(Inte8)+xi(m*da)*I2(i,m+1));
     
     
    %D_9(i)=sum(Inte9);
    
     %----------------��ֵ����----------------------------------------------
    %s(i,1)=1e6;
    E(i,1)=S(i)*(D_1+D_2+D_3);
    I1(i,1)=delta*D_4+omega*D_5;
    I2(i,1)=D_6+sigma*D_7;
    L1(i,1)=eta*D_8;
    L2(i,1)=D_9;
     I3(i,1)=theta*D_10+D_11;
       
    %-------------�������ι�ʽ----------------------------------------------
    
   
    
  %-----------------------ϵͳ����-----------------------------------------
  S(i+1)=S(i)+dt*(Lambda-(mu1)*S(i)-S(i)*(D_1+D_2+D_3));
  %I(i+1)=I(i)+dt*(D_2-(mu+delta+k)*I(i)+D_3);
    for j=2:m+1
      %s(i+1,j)=s(i,j)+dt*(-(s(i,j)-s(i,j-1))/da-(mu((j-1)*da))*v(i,j));   
        
        E(i+1,j)=E(i,j)+dt*(-(E(i,j)-E(i,j-1))/da-(mu2+delta)*E(i,j));
        
    I1(i+1,j)=I1(i,j)+dt*(-(I1(i,j)-I1(i,j-1))/da-(mu3+sigma)*I1(i,j));
    I2(i+1,j)=I2(i,j)+dt*(-(I2(i,j)-I2(i,j-1))/da-(mu4+eta+xi((j-1)*da))*I2(i,j));
    L1(i+1,j)=L1(i,j)+dt*(-(L1(i,j)-L1(i,j-1))/da-(mu5+xi((j-1)*da))*L1(i,j)); 
    L2(i+1,j)=L2(i,j)+dt*(-(L2(i,j)-L2(i,j-1))/da-(mu6+theta)*L2(i,j)); 
     I3(i+1,j)=I3(i,j)+dt*(-(I3(i,j)-I3(i,j-1))/da-(mu7+d)*I3(i,j));
    
    end
%         %----------------��ֵ����----------------------------------------------
%     v(i+1,1)=xi*S(i+1);
%     e(i+1,1)=beta*S(i+1)*0.8*I(i+1)/(1+0.2*I(i+1));
%     r(i+1,1)=k*I(i+1);    
end

%----------------------------��ͼ------------------------------------------
IntI1(1)=40188;
IntI2(1)=30527;
IntL(1)=18884;
IntI3(1)=523;
for i=1:n
for j=2:m+1
    IntI1(i+1) = IntI1(i)+I1(i,j);
     IntI2(i+1) = IntI2(i)+I2(i,j);
     
      IntL(i+1) = IntL(i)+L1(i,j)+L2(i,j);
      
      IntI3(i+1) = IntI3(i)+I3(i,j);
     
%IntR(n) = IntR(n)+r(j,n)*h;
%IntU1(n) = IntU1(n)+u1(j,n)*h;
%IntU2(n) = IntU2(n)+u2(j,n)*h;
end
end





 [x1,y1]=size((I1)');
X1=linspace(0,100,x1);
Y1=linspace(0,T,y1);

figure(1);
mesh(Y1,X1,E')
xlabel('t'),ylabel('a'),zlabel('E(a,t)');
set(gca,'FontSize',25)

figure(2);
mesh(Y1,X1,I1')
xlabel('t'),ylabel('a'),zlabel('I_1(a,t)');
set(gca,'FontSize',25)


figure(3);
mesh(Y1,X1,I2')
xlabel('t'),ylabel('a'),zlabel('I_2(a,t)');
set(gca,'FontSize',25)

figure(4);
mesh(Y1,X1,L1')
xlabel('t'),ylabel('a'),zlabel('L_1(a,t)');
set(gca,'FontSize',25)
figure(5);
mesh(Y1,X1,L2')
xlabel('t'),ylabel('a'),zlabel('L_2(a,t)');
set(gca,'FontSize',25)


figure(6);
mesh(Y1,X1,I3')
xlabel('t'),ylabel('a'),zlabel('I_3(a,t)');
set(gca,'FontSize',25)




figure(15)
plot(Y1,IntI1,'b','LineWidth',2)
axis([0 14 0 1.4e6]);%������������ʾ��Χ12:26
%set(gca,'XTickLabel',{'2005','2007','2009','2011','2013','2015','2017','2019','2021'});
set(gca,'XTickLabel',{'2004','2006','2008','2010','2012','2014','2016','2018'});

xtickangle(45)
xlabel('Time (Years) ','FontSize',25);
ylabel('\int_{0}^{\infty}I_1(a,t)da','FontSize',20);
hold on

grid on

figure(16)
plot(Y1,IntI1*2/12,'m','LineWidth',2)
axis([0 14 0 8e5]);%������������ʾ��Χ12:26
%set(gca,'XTickLabel',{'2005','2007','2009','2011','2013','2015','2017','2019','2021'});
set(gca,'XTickLabel',{'2004','2006','2008','2010','2012','2014','2016','2018'});


xtickangle(45)
xlabel('Time (Years) ','FontSize',25);
ylabel('\int_{0}^{\infty}I_2(a,t)da','FontSize',20);
hold on
grid on

figure(17)
plot(Y1,IntL,'m','LineWidth',2)
axis([0 14 0 3e6]);%������������ʾ��Χ12:26
%set(gca,'XTickLabel',{'2005','2007','2009','2011','2013','2015','2017','2019','2021'});
set(gca,'XTickLabel',{'2004','2006','2008','2010','2012','2014','2016','2018'});


xtickangle(45)
xlabel('Time (Years) ','FontSize',25);
ylabel('\int_{0}^{\infty}(L_1(a,t)+L_2(a,t))da','FontSize',20);
hold on
grid on
figure(18)
plot(Y1,IntI3,'m','LineWidth',2)
axis([0 14 0 4e4]);%������������ʾ��Χ12:26
%set(gca,'XTickLabel',{'2005','2007','2009','2011','2013','2015','2017','2019','2021'});
set(gca,'XTickLabel',{'2004','2006','2008','2010','2012','2014','2016','2018'});


xtickangle(45)
xlabel('Time (Years) ','FontSize',25);
ylabel('\int_{0}^{\infty}I_3(a,t)da','FontSize',20);
hold on
grid on


