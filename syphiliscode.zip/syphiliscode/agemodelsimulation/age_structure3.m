


function  age_structure1(T)
%----------------ϵͳ����---------------------------------------------------
T=50;
dt=0.1;
n=T/dt;
da=0.2;
m=10/da;
%mu='0.1291+3.84e-4*exp(0.0788*x)-0.0136*exp(-0.0788*x)';
mu='0.0191+3.84e-4*exp(0.0788*x)-0.0136*exp(-0.0788*x)';
%mu='0.0191';
mu=inline(mu);
%d='0.1458+1.307e-5*exp(0.1446*x)-0.3653*exp(-0.1446*x)';
d='0';
d=inline(d);
alpha='0.076+3.22e-10*exp(0.2985*x)-1.0191*exp(-0.2985*x)';
%alpha='0.016';
alpha=inline(alpha);
omega='0.0183+2.83e-9*exp(0.2535*x)+4.624*exp(-0.2535*x)';
%omega='0.0183';
omega=inline(omega);
%phi='0.05371+2.4e-10*exp(0.3928*x)-0.335*exp(-0.3928*x)';
phi='0.03';
phi=inline(phi);
%beta='1.944e-7*(4.107e-4*(-(x-40)^2+2.1935e3)+5.720e-2)';
beta='8.944e-5*(4.107e-4*(-(x-40)^2+2.1935e3)+5.720e-2)';
beta=inline(beta);
gamma=0.15;
c1=0.02;
c2=0.65;
c3=0.3;
theta=0.025;%0.085,0.045;

Lambda=2e5;
delta=0.019;
IntV=zeros(1,n)



%-----------------------��ֵ����-------------------------------------------
S(1)=1e6;
for j=1:m+1
    %s(1,j)=4e4;
    l(1,j)=800;
  v(1,j)=386;
  e(1,j)=304;
  r(1,j)=17;
end
%--------------------ϵͳ��ɢ��---------------------------------------------
for i=1:n
      for p=2:m
        Inte1(p)=beta((p-1)*da)*v(i,p);
        Inte2(p)=beta((p-1)*da)*c1*l(i,p);
        Inte3(p)=beta((p-1)*da)*c2*e(i,p);
       Inte4(p)=beta((p-1)*da)*c3*r(i,p);
       Inte5(p)=phi((p-1)*da)*l(i,p);
       Inte6(p)=omega((p-1)*da)*v(i,p);
       Inte7(p)=(1-omega((p-1)*da))*v(i,p);
        Inte8(p)=(alpha((p-1)*da))*e(i,p);
        Inte9(p)=v(i,p);
      end
    D_1=(dt/2)*(beta(0*da)*v(i,1)+2*sum(Inte1)+beta(m*da)*v(i,m+1)); 
    D_2=(dt/2)*(beta(0*da)*c1*l(i,1)+2*sum(Inte2)+beta(m*da)*c1*l(i,m+1)); 
    D_3=(dt/2)*(beta(0*da)*c2*e(i,1)+2*sum(Inte3)+beta(m*da)*c2*e(i,m+1)); 
     D_4=(dt/2)*(beta(0*da)*c3*r(i,1)+2*sum(Inte4)+beta(m*da)*c3*r(i,m+1)); 
      D_5=(dt/2)*(phi(0*da)*l(i,1)+2*sum(Inte5)+phi(m*da)*l(i,m+1)); 
    D_6=(dt/2)*(omega(0*da)*v(i,1)+2*sum(Inte6)+omega(m*da)*v(i,m+1)); 
    D_7=(dt/2)*((1-omega(0*da))*v(i,1)+2*sum(Inte7)+(1-omega(m*da))*v(i,m+1)); 
    D_8=(dt/2)*(alpha(0*da)*e(i,1)+2*sum(Inte8)+alpha(m*da)*e(i,m+1));
    %D_9(i)=sum(Inte9);
    
     %----------------��ֵ����----------------------------------------------
    %s(i,1)=1e6;
    l(i,1)=S(i)*(D_1+D_2+D_3+D_4);
     v(i,1)=D_5;
    e(i,1)=gamma*D_6;
    r(i,1)=gamma*D_7+D_8;   
    %-------------�������ι�ʽ----------------------------------------------
    
   
    
  %-----------------------ϵͳ����-----------------------------------------
  S(i+1)=S(i)+dt*(Lambda-(delta+theta)*S(i)-S(i)*(D_1+D_2+D_3+D_4));
  %I(i+1)=I(i)+dt*(D_2-(mu+delta+k)*I(i)+D_3);
    for j=2:m+1
      %s(i+1,j)=s(i,j)+dt*(-(s(i,j)-s(i,j-1))/da-(mu((j-1)*da))*v(i,j));   
        
        l(i+1,j)=l(i,j)+dt*(-(l(i,j)-l(i,j-1))/da-(mu((j-1)*da)+phi((j-1)*da))*l(i,j));
        
    v(i+1,j)=v(i,j)+dt*(-(v(i,j)-v(i,j-1))/da-(gamma+mu((j-1)*da))*v(i,j));
    e(i+1,j)=e(i,j)+dt*(-(e(i,j)-e(i,j-1))/da-(mu((j-1)*da)+alpha((j-1)*da))*e(i,j));
    r(i+1,j)=r(i,j)+dt*(-(r(i,j)-r(i,j-1))/da-(mu((j-1)*da)+d((j-1)*da))*r(i,j)); 
    end
%         %----------------��ֵ����----------------------------------------------
%     v(i+1,1)=xi*S(i+1);
%     e(i+1,1)=beta*S(i+1)*0.8*I(i+1)/(1+0.2*I(i+1));
%     r(i+1,1)=k*I(i+1);    
end

%----------------------------��ͼ------------------------------------------
IntV(1)=2978;
for i=1:n
for j=2:m+1
    IntV(i+1) = IntV(i)+v(i,j);
%IntR(n) = IntR(n)+r(j,n)*h;
%IntU1(n) = IntU1(n)+u1(j,n)*h;
%IntU2(n) = IntU2(n)+u2(j,n)*h;
end
end





 [x1,y1]=size((v)');
X1=linspace(0,60,x1);
Y1=linspace(0,T,y1);

figure(1);
mesh(Y1,X1,v')
xlabel('t'),ylabel('a'),zlabel('I(a,t)');
figure(2);
mesh(Y1,X1,e')
xlabel('t'),ylabel('a'),zlabel('T(a,t)');
figure(3);
mesh(Y1,X1,-r')
xlabel('t'),ylabel('a'),zlabel('A(a,t)');
axis([0 50 0 60 0 0.1e4]);

figure(4);
mesh(Y1,X1,l')
xlabel('t'),ylabel('a'),zlabel('L(a,t)');


figure(5)
plot(Y1,IntV,'b','LineWidth',2)
axis([12 26 0 1.2e6]);%������������ʾ��Χ12:26
%set(gca,'XTickLabel',{'2005','2007','2009','2011','2013','2015','2017','2019','2021'});
set(gca,'XTickLabel',{'2004','2006','2008','2010','2012','2014','2016','2018'});
grid on


figure(6)
plot(Y1,IntV,'b','LineWidth',2)
axis([6 20 0 9e5]);%������������ʾ��Χ12:26
%set(gca,'XTickLabel',{'2005','2007','2009','2011','2013','2015','2017','2019','2021'});
set(gca,'XTickLabel',{'2004','2006','2008','2010','2012','2014','2016','2018'});

grid on

xtickangle(45)
xlabel('Time (Years) ','FontSize',25);
ylabel('\int_{0}^{\infty}I(a,t)da','FontSize',20);
hold on


