clc
clear

%cases1=[5569	6328	7389	8396	9935	11755	13552	14257	13438	11719	9961	7860	5889	5390	4763]';%20-24��һ��÷��
%cases1=[4379	5009	5628	6554	7790	9108	10065	10584	10563	9944	9332	7790	6284	5914	5887]';%20-24�����÷��
cases1=[2301	4362	6463	8138	10223	12507	16475	19525	20135	20715	22147	22933	23160	24391	24812]';%20-24������÷��
%cases1=[38	53	74	69	89	91	108	111	111	101	105	115	90	87	101]';%20-24��������÷��




n=length(cases1);
days=[1:1:n]';%����
data1=[days,cases1];
data2=[days,cases1];
nsimu= 20000;   % number of simulations
model.S20 = 1;
model.N0  = 4;
options.nsimu=nsimu;         % n:o of simulations

%%
% The model sum of squares in file <algaess.html |algaess.m|> is
% given in the model structure.
model.ssfun = @modelss;
k0=[0.35,0.46,0.22,0.73,0.5,0.43,0.5,0.6,1.5e6,4e5];
%%
% All parameters are constrained to be positive. The initial
% concentrations are also unknown and are treated as extra parameters.
params = {
    %{'\gamma_1', k0(1),  0, 1}
{'\zeta_5', k0(1),  0, 1}
{'\theta_5', k0(2),  0, 1}
    {'\xi_5', k0(3),  0, 1}
   
    {'\omega_5',  k0(4),  0, 1}
    {'\epsilon_5',  k0(5),  0, 1}
    {'\alpha_5',  k0(6),  0, 1}
     {'\beta_5',  k0(7),  0, 1}
      {'\gamma_5',  k0(8),  0, 1}
       {'\Lambda',  k0(9),  0, 10000000}
     {'E(0)',  k0(10),  0, 1000000}
    };


%%
% First generate an initial chain.

results = [];
[results, chain, s2chain,sschain]=mcmcrun(model,data1,params,options,results);


save data;

%%
% Chain plots should reveal that the chain has converged and we can
% use the results for estimation and predictive inference.
figure(1); clf
mcmcplot(chain,[],results);
figure(2); clf
mcmcplot(chain(10001:20000,:),[],results,'hist',30)
%plot(chain(10001:20000,:),'\epsilon',results,'hist',20)


figure(3); clf
mcmcplot(chain(10001:20000,:),[],results,'pairs');
figure(4); clf
mcmcplot(chain(10001:20000,:),[],results,'denspanel',2);

%%
% Function |chainstats| calculates mean ans std from the chain and
% estimates the Monte Carlo error of the estimates. Number |tau| is
% the integrated autocorrelation time and |geweke| is a simple test
% for a null hypothesis that the chain has converged.
chainstats(chain,results)

%%
% In order to use the |mcmcpred| function we need
% function |modelfun| with input arguments given as
% |modelfun(xdata,theta)|. We construct this as an anonymous function.
y0 =[80596000,17000,5569,460,1841,460,38]; %ģ�ͳ�ֵ
%modelfun1 = @ (d,th)modelfunX(d(:,1),th,y0);
modelfun1 = @ (d,th)modelfunX(d(:,1),th([1:9]),[y0(1),th(10),y0(3),y0(4),y0(5),y0(6),y0(7)]);
%modelfun2 = @ (d,th)modelfunY(d(:,1),th,y0);
modelfun2 = @ (d,th)modelfunY(d(:,1),th([1:9]),[y0(1),th(10),y0(3),y0(4),y0(5),y0(6),y0(7)]);
%%
nsample = 10000;
out1 = mcmcpred(results,chain,[],data1,modelfun1,nsample);
out2 = mcmcpred(results,chain,[],data1,modelfun2,nsample);
figure(5); clf
mcmcpredplot(out1);
hold on
plot(data1(:,1),data1(:,2),'ro'); 
axis([0.4 15.6 0 inf])
grid on
set(gca,'FontSize',30)
xlabel('Year')
ylabel('Newly tertiary stage syphilis cases')




figure(6); clf
mcmcpredplot(out2);
hold on
plot(data1(:,1),cumsum(data1(:,2)),'ro', 'LineWidth',4); 
axis([0.4 15.6 0 inf])
grid on
set(gca,'FontSize',30)
xlabel('Year')
ylabel('Cumulative tertiary stage syphilis cases')
