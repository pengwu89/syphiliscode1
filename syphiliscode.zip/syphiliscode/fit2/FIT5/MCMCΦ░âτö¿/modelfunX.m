function Y=modelfunX(time,theta,y0)
% model function

[t,x] = ode15s(@modelling,time,y0,[],theta);

for i=1:(length(x(:,5))-1)
    X(i+1)=x(i+1,5)-x(i,5)+x(i+1,4)-x(i,4);
end
X(1)=x(1,5)+x(1,4);
Y=X';