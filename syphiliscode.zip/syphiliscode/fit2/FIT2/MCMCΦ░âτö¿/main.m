clc
clear

%cases1=[130	280	400	480	480	550	690	550	530	340	130	230	160	150	100]';%5-9��һ��÷��330
cases1=[4	0	1	2	2	1	0	0	0	0	0	0	1	0	1]';%5-9�����÷��
%cases1=[21	6	8	8	8	9	5	5	4	1	5	4	3	4	1]';%5-9������÷��
%cases1=[15	26	65	85	116	115	114	125	108	95	84	83	73	68	84]';%5-9��������÷��




n=length(cases1);
days=[1:1:n]';%����
data1=[days,cases1];
data2=[days,cases1];
nsimu= 20000;   % number of simulations
model.S20 = 1;
model.N0  = 4;
options.nsimu=nsimu;         % n:o of simulations

%%
% The model sum of squares in file <algaess.html |algaess.m|> is
% given in the model structure.
model.ssfun = @modelss;
k0=[0.0184,0.215,0.31,0.45,0.455,0.48,0.45,0.5,4.9e6,5e5];
%%
% All parameters are constrained to be positive. The initial
% concentrations are also unknown and are treated as extra parameters.
params = {
    %{'\gamma_1', k0(1),  0, 1}
{'\zeta_2', k0(1),  0, 1}
{'\theta_2', k0(2),  0, 1}
    {'\xi_2', k0(3),  0, 1}
   
    {'\omega_2',  k0(4),  0, 1}
    {'\epsilon_2',  k0(5),  0, 1}
    {'\alpha_2',  k0(6),  0, 1}
     {'\beta_2',  k0(7),  0, 1}
      {'\gamma_2',  k0(8),  0, 1}
       {'\Lambda',  k0(9),  0, 10000000}
     {'E(0)',  k0(10),  0, 1000000}
    };


%%
% First generate an initial chain.

results = [];
[results, chain, s2chain,sschain]=mcmcrun(model,data1,params,options,results);


save data;

%%
% Chain plots should reveal that the chain has converged and we can
% use the results for estimation and predictive inference.
figure(1); clf
mcmcplot(chain,[],results);
figure(2); clf
mcmcplot(chain(10001:20000,:),[],results,'hist',30)
%plot(chain(10001:20000,:),'\epsilon',results,'hist',20)


figure(3); clf
mcmcplot(chain(10001:20000,:),[],results,'pairs');
figure(4); clf
mcmcplot(chain(10001:20000,:),[],results,'denspanel',2);

%%
% Function |chainstats| calculates mean ans std from the chain and
% estimates the Monte Carlo error of the estimates. Number |tau| is
% the integrated autocorrelation time and |geweke| is a simple test
% for a null hypothesis that the chain has converged.
chainstats(chain,results)

%%
% In order to use the |mcmcpred| function we need
% function |modelfun| with input arguments given as
% |modelfun(xdata,theta)|. We construct this as an anonymous function.
y0 =[111127000,1700000,130,20,120,4,21]; %ģ�ͳ�ֵ
%modelfun1 = @ (d,th)modelfunX(d(:,1),th,y0);
modelfun1 = @ (d,th)modelfunX(d(:,1),th([1:9]),[y0(1),th(10),y0(3),y0(4),y0(5),y0(6),y0(7)]);
%modelfun2 = @ (d,th)modelfunY(d(:,1),th,y0);
modelfun2 = @ (d,th)modelfunY(d(:,1),th([1:9]),[y0(1),th(10),y0(3),y0(4),y0(5),y0(6),y0(7)]);
%%
nsample = 10000;
out1 = mcmcpred(results,chain,[],data1,modelfun1,nsample);
out2 = mcmcpred(results,chain,[],data1,modelfun2,nsample);
figure(5); clf
mcmcpredplot(out1);
hold on
plot(data1(:,1),data1(:,2),'rs'); 
axis([0.4 15.6 0 inf])
grid on
set(gca,'FontSize',30)
xlabel('Year')
ylabel('Newly secondary stage syphilis cases')




figure(6); clf
mcmcpredplot(out2);
hold on
plot(data1(:,1),cumsum(data1(:,2)),'rs', 'LineWidth',4); 
axis([0.4 15.6 0 inf])
grid on
set(gca,'FontSize',30)
xlabel('Year')
ylabel('Cumulative secondary stage syphilis cases')
