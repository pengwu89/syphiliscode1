function Y=modelfunX(time,theta,y0)
% model function

[t,x] = ode15s(@modelling,time,y0,[],theta);

for i=1:(length(x(:,6))-1)
    X(i+1)=x(i+1,6)-x(i,6);
end
X(1)=x(1,6);
Y=X';