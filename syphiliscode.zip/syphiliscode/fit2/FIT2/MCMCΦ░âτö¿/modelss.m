function ss = modelss(theta,data1)
%  sum-of-squares function

time   = data1(:,1);
ydata  = data1(:,2);

y0 =[111127000,theta(end),130,20,120,4,21]; %ģ�ͳ�ֵ330

ymodel = modelfunX(time,theta,y0);
ss = sum((ymodel- ydata).^2);
