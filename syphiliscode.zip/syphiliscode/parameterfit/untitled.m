xmin=1;
xmax=5;
ymin=-1.5;
ymax=1.5;

x=-1.5:0.1:5;
y1=sin(x);
ny=length(y1);
xd=sort(x,'descend');
y1d=y1(end:-1:1);
nx=length(x);
y2=ymax*ones(1,nx);
plot(x,y1)
hold on

 h1=fill([x,xd],[y2,y1d],'y')
 set(h1,'edgealpha',0,'facealpha',0.2) ;
 y22=ymin*ones(1,nx);
 hold on
 h2=fill([x,xd],[y1,y22],'c')
 set(h2,'edgealpha',0,'facealpha',0.2) 
 hold on
axis([xmin xmax ymin ymax])
