%script model B

%% TB1
figure(401)
[R0,phi]=R0_B(1000,1,2,[1/4,2/5,62475/200]);
Phi_r=R0eigenfunction_B(1,[R0,2/5,62475/200]);
%[R0,R0_e,Phi,Phi_e]=R0error_B([2:30],1,2,[1/4,2/5,62475/256],R0,Phi_r);
[R0,phi]=R0_B(1000,1,2,[1/4,0,80325/200]);
Phi_r=R0eigenfunction_B(1,[R0,0,80325/200]);
%[R0,R0_e,Phi,Phi_e]=R0error_B([2:30],1,2,[1/4,0,80325/256],R0,Phi_r);
legend({'$|R_{0,N}-R_{0}|$, (T1.1B)','$\|\phi_{N}-\phi\|_{\infty}$, (T1.1B)','$|R_{0,N}-R_{0}|$, (T1.2B)','$\|\phi_{N}-\phi\|_{\infty}$, (T1.2B)'},'interpreter','latex')
axis([2 30 1e-16 1])
xticks(5:5:30)
yticks([1e-15,1e-10,1e-5,1e-0])
figure(402)
[R0,phi]=R0_B(1000,1,2,[1,2/5,1155/4]);
Phi_r=R0eigenfunction_B(1,[R0,2/5,1155/4]);
%[R0,R0_e,Phi,Phi_e]=R0error_B([2:30],1,2,[1,2/5,1155/4],R0,Phi_r);
[R0,phi]=R0_B(1000,1,2,[1,0,1575/4]);
Phi_r=R0eigenfunction_B(1,[R0,0,1575/4]);
%[R0,R0_e,Phi,Phi_e]=R0error_B([2:30],1,2,[1,0,1575/4],R0,Phi_r);
legend({'$|R_{0,N}-R_{0}|$, (T1.3B)','$|R_{0,N}-R_{0}|$, (T1.4B)'},'interpreter','latex')
axis([2 30 1e-16 1])
xticks(5:5:30)
yticks([1e-15,1e-10,1e-5,1e-0])

%% TB2
%[R0,phi]=R0_B(1000,2,1,[0,141]);R0

figure(403) %theta=0
%new K (discontinuous)
[R0]=R0_B(1000,2,1,[0,141]);
[R0,R0_e]=R0error_B([10:10:100,150:50:1000],2,1,[0,141],R0,phi);

%[R0,R0_e,Phi,Phi_e]=R0error_B([10:10:100,150:50:1000],2,1,[0,141],R0,phi);
%old K (continuous)
%[R0,phi]=R0_B(1000,2,1,[0,189]);R0
%[R0,R0_e,Phi,Phi_e]=R0error_B([10:10:100,150:50:1000],2,1,[0,189],R0,phi);
axis([10 1000 1e-12 1])
xticks([10, 100, 300, 412, 424,440,466,500,515,540,560,650,690,730,800,850,900,940,955,970,985,1000])
yticks([1e-10,1e-5,1e-0])
legend({'$|R_{0,N}-R_{0}|$'},'interpreter','latex')
figure(404) %theta=2/5
%new K (discontinuous)
[R0,phi]=R0_B(1000,2,1,[2/5,124]);
[R0,R0_e,Phi,Phi_e]=R0error_B([10:10:100,150:50:1000],2,1,[2/5,124],R0,phi);
%old K (continuous)
%[R0,phi]=R0_B(1000,2,1,[2/5,137]);R0
%[R0,R0_e,Phi,Phi_e]=R0error_B([10:10:100,150:50:1000],2,1,[2/5,137],R0,phi);
axis([5 1000 1e-12 1])
xticks([5,10,20,50,100,300,600,1000])
yticks([1e-10,1e-5,1e-0])
legend({'$|R_{0,N}-R_{0}|$, (T2.2B)','$|R_{0,N}-R_{0}|$, (T2.4B)'},'interpreter','latex')



