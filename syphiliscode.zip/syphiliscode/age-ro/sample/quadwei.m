function w=quadwei(N)
%QUADWEI Clenshaw-Curtis quadrature.
%   w=QUADWEI(N) returns the normalized weights of the Clenshaw-Curtis 
%   quadrature in [-1,1] according to [1].
%   INPUT:
%      N: degree of discretization (1x1)
%   OUTPUT:
%      w: weights ((N+1)x1)
%      x: nodes ((N+1)x1)
%
%  References:
%   [1] L.N. Trefethen, "Spectral methods in Matlab", SIAM, 2000.

p=pi*(0:N)'/N;
x=cos(p);
w=zeros(1,N+1);
ii=2:N;
v=ones(N-1,1);
if mod(N,2)==0
    w(1)=1/(N^2-1);
    w(N+1)=w(1);
    for k=1:N/2-1
        v=v-2*cos(2*k*p(ii))/(4*k^2-1);
    end
    v=v-cos(N*p(ii))/(N^2-1);
else
    w(1)=1/N^2;
    w(N+1)=w(1);
    for k=1:(N-1)/2
        v=v-2*cos(2*k*p(ii))/(4*k^2-1);
    end
end
w(ii)=2*v/N;
