function Phi_r=R0eigenfunction_B(flag_model,par)
%
%  Copyright (c) 2020-2021 Dimitri Breda.
%  R0eigenfunction_B is distributed under the terms of the MIT license.
%
%  If you use this software for a scientific publication,
%  please cite the following publications:
%
%  [1] D. Breda, F. Florian, J. Ripoll, R. Vermiglio,Efficient numerical computation
%      of the basic reproduction number for structured populations, Journal of Computational
%      and Applied Mathematics, https://doi.org/10.1016/j.cam.2020.113165.
%
%  [2] D. Breda, T. Kuniya, J. Ripoll, R. Vermiglio, Collocation of Next-Generation 
%      Operators for Computing the Basic Reproduction Number of Structured Populations. 
%      J Sci Comput, https://doi.org/10.1007/s10915-020-01339-1.

l=1;
if flag_model==1
    R0=par(1);
    theta=par(2);
    ktilde=par(3);
    C=theta*R0/ktilde;
    phi=@(x)x.^3.*(l-x).*(4*l-3*x)/10+(1-x/l)*C;
elseif flag_model==2 %other models
    phi=@(x)x.^3.*(l-x).*(4*l-3*x)/10;
end
xx=linspace(0,l,1000)';
Phi_r=zeros(size(xx));
for i=1:length(xx)
    Phi_r(i)=phi(xx(i));
end
Phi_r=abs(Phi_r./max(abs(Phi_r)));
% plot(xx,Phi_r,'-r');