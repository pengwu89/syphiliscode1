function [R0,phi]=R0_B(N,flag_model,flag_method,par)

%  Copyright (c) 2020-2021 Dimitri Breda.
%  R0_B is distributed under the terms of the MIT license.
%
%  If you use this software for a scientific publication,
%  please cite the following publications:
%
%  [1] D. Breda, F. Florian, J. Ripoll, R. Vermiglio,Efficient numerical computation
%      of the basic reproduction number for structured populations, Journal of Computational
%      and Applied Mathematics, https://doi.org/10.1016/j.cam.2020.113165.
%
%  [2] D. Breda, T. Kuniya, J. Ripoll, R. Vermiglio, Collocation of Next-Generation 
%      Operators for Computing the Basic Reproduction Number of Structured Populations. 
%      J Sci Comput, https://doi.org/10.1007/s10915-020-01339-1.
%
%   R0_B numerical computation of R_0.
%   [R0,phi]=R0_B(N,flag_model,flag_method,par) returns the pseudospectral
%   collocation approximation of the basic reproduction number for the
%   class of models B (age-epidemic models).
%
%   INPUT:
%              N: degree of discretization (1x1)
%     flag_model: choice of model coefficients (1x1)
%    flag_method: 1=all nodes, 2=drop last node (1x1)
%            par: vector of possible parameters (px1)
%   OUTPUT:
%             R0: approximation of R_0 (1x1)
%            phi: barycentric polynomial approximation of relevant 
%                 eigenfunction on 1000 equispaced points in [0,l] (1000x1)

%% model coefficients
l=1;
if flag_model==1 %proportionate mixing
    alpha=par(1);
    theta=par(2);
    Pi0=@(a)((l-a)/l).^alpha;
    gamma=@(a)1./(l-a)/2;
    delta=@(a)1./(l-a)/2;
    ktilde=par(3);
    K1=@(a,x)(a.^2.*(l-a).^2)*ktilde*(alpha+1)/l*Pi0(x);
    beta1=@(a)(alpha+1)*(l-a).^alpha/(l^(alpha+1));
    R0_r=2*ktilde*(alpha+1)*l^5/...
        ((alpha+2-theta*(alpha+1))*...
        (alpha+4)*(alpha+5)*(alpha+6));
    %R0=2.500000000000004, alpha=1/4,theta=2/5,ktilde=62475/256; (new)
    %R0=2.499999999999989, alpha=1/4,theta=0,ktilde=80325/256; (new)
    %R0=2.499999999999982, alpha=1,theta=2/5,ktilde=1155/4; (new)
    %R0=2.500000000000000, alpha=1,theta=0,ktilde=1575/4; (new)
elseif flag_model==2 %general case
    alpha=.1;
    Pi0=@(a)exp(-alpha*a./(l-a));
    beta0=@(a)(a/l).^2.*exp(-6*a/l);
    gammatilde=9/2;
    gamma=@(a)gammatilde*ones(size(a));
    deltatilde=9/2;
    delta=@(a)deltatilde*ones(size(a));
    ktilde=par(2);%42;
    l0=0.1*l;
    K1=@(a,x)K1fun(a,x,l,ktilde,alpha,Pi0,l0);
    theta=par(1);
    %R0=2.499486715274162, N=1000, theta=0, ktilde=141, disc. K; (new)
    %R0=2.506858993699479, N=1000, theta=2/5, ktilde=124, disc. K; (new)
    %R0=2.504893610018024, N=1000, theta=0, ktilde=189, cont. K; (new)
    %R0=2.501711815944655, N=1000, theta=2/5, ktilde=137, cont. K; (new)
end

%% Chebyshev nodes, diff. matrix and quad. weights
[H,x]=difmat(0,l,N);
w=quadwei(N);

if flag_model==2
    norma=(l/2)*w*(beta0(x).*Pi0(x));
    beta1=@(x)beta0(x).*Pi0(x)/norma;
end

%% birth operator
B=(l/2)*K1(x,x')*diag(w);
B(1,:)=zeros(1,N+1);
if flag_method==2
    B=B(1:N,1:N);
end

%% mortality operator
M=H+diag(gamma(x)+delta(x));
M(1,:)=-theta*(l/2)*beta1(x').*w;
M(1,1)=M(1,1)+1;
if flag_method==2
    M=M(1:N,1:N);
    x=x(1:N);
end

%% eigenvalue problem
% [Phi,R0]=eig(B,M);
[Psi,R0]=eig(B/M);Phi=M\Psi;
R0=abs(diag(R0));
[R0,ind]=sort(R0,'descend');
R0=R0(1);
Phi=Phi(:,ind);
Phi=Phi(:,1);
xx=linspace(0,l,1000)';
phi=bary(xx,Phi,x,bary_weights(x));
if flag_model==1
    phi=abs(phi./max(abs(phi)));
%     plot(xx,phi,'-k')
elseif flag_model==2
    phi=abs(phi./max(abs(phi)));
%     plot(xx,phi,'-k')
end

%% K1 for general case
function k1=K1fun(a,x,l,ktilde,alpha,Pi0,l0)
for i=1:length(a)
    for j=1:length(x)
%         k1(i,j)=(exp(-abs(a(i)-x(j))/l0))*ktilde*Pi0(x(j))/...
%             (l*(1-alpha*(exp(alpha)*expint(alpha))));
%         k1(i,j)=exp(-abs((a(i)-x(j))*...
%             ((a(i)-x(j))^2-(l/3)^2)*...
%             ((a(i)-x(j))^2-(2*l/3)^2))/(l0^3))*...
%             ktilde*Pi0(x(j))/...
%             (l*(1-alpha*(exp(alpha)*expint(alpha))));
        k1(i,j)=(exp(-((a(i)-x(j))/l0)^2))*ktilde*Pi0(x(j))/...
            (l*(1-alpha*(exp(alpha)*expint(alpha))));
    end
end