function [R0,R0_e,Phi,Phi_e]=R0error_B(N,flag_model,flag_method,par,R0_r,Phi_r)

%  Copyright (c) 2020-2021 Dimitri Breda.
%  R0error_B is distributed under the terms of the MIT license.
%
%  If you use this software for a scientific publication,
%  please cite the following publications:
%
%  [1] D. Breda, F. Florian, J. Ripoll, R. Vermiglio,Efficient numerical computation
%      of the basic reproduction number for structured populations, Journal of Computational
%      and Applied Mathematics, https://doi.org/10.1016/j.cam.2020.113165.
%
%  [2] D. Breda, T. Kuniya, J. Ripoll, R. Vermiglio, Collocation of Next-Generation 
%      Operators for Computing the Basic Reproduction Number of Structured Populations. 
%      J Sci Comput, https://doi.org/10.1007/s10915-020-01339-1.
%
%  R0error_B numerical computation error of R_0 and relevant eigenfunction.
%  [R0,R0_e,Phi,Phi_e]=R0error_B(N,flag_model,flag_method,par,R0_r,Phi_r) 
%  returns the errors for varying degree of approximation in the
%  pseudospectral collocation approximation of the basic reproduction
%  number and of the relevant eigenfunction for the class of models B
%  (age-epidemic models).
%   INPUT:
%              N: vector of degrees of discretization (1xlength(N))
%     flag_model: choice of model coefficients (1x1)
%    flag_method: 1=all nodes, 2=drop last node (1x1)
%            par: vector of possible parameters (px1)
%           R0_r: reference value for R0 (1x1)
%          Phi_r: reference value for Phi (@)
%   OUTPUT:
%             R0: approximation of R_0 (1xlength(N))
%           R0_e: error on R_0 (1xlength(N))
%            Phi: barycentric polynomial approximation of relevant 
%                 eigenfunction on 1000 equispaced points in [0,l]
%                 (1000xlength(N))
%          Phi_e: error on relevant eigenfunction (1xlength(N))

R0=zeros(1,length(N));
R0_e=zeros(1,length(N));
Phi=zeros(1000,length(N));
Phi_e=zeros(1,length(N));
for n=1:length(N)
    [r0,phi]=R0_B(N(n),flag_model,flag_method,par);
    R0(n)=r0;
    R0_e(n)=abs(R0(n)-R0_r);
    Phi(:,n)=phi;
    Phi_e(n)=max(abs(phi-Phi_r));
end
% figure
loglog(N,R0_e,'-.k.','markersize',30)
hold on,grid on
loglog(N,Phi_e,'-.ko','markersize',8)
legend({'$|R_{0,N}-R_{0}|$','$\|\phi_{N}-\phi\|_{\infty}$'},'interpreter','latex')
xlabel('$N$','interpreter','latex')
% ylabel('$|R_{0,N}-R_{0}|$','interpreter','latex')
% xticks([5:5:30,40])
% yticks(10.^(-16:-4:0))
axis([2 max(N) 1e-16 1])
set(gca,'fontsize',24,'fontname','times new roman')