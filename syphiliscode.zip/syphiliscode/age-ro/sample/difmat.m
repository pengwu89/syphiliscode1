function [D,x]=difmat(a,b,N)
%DIFMAT  Chebyshev nodes and pseudospectral differentiation matrix.
%  [D,x]=DIFMAT(a,b,N) returns the pseudospectral differentiation
%   matrix D of order N+1 on the N+1 Chebyshev nodes x in [a,b]
%   according to [1].
%   INPUT:
%      a: left extremum (1x1)
%      b: right extremum (1x1)
%      N: degree of discretization (1x1)
%   OUTPUT:
%      D: differentiation matrix ((N+1)x(N+1))
%      x: Chebyshev nodes ((N+1)x1)
%
%  References:
%   [1] L.N. Trefethen, "Spectral methods in Matlab", SIAM, 2000.

if N==0
    x=1;
    D=0;
    return
end
x=(b+a-(b-a)*(cos(pi*(0:N)'/N)))/2;
c=[2;ones(N-1,1);2].*(-1).^(0:N)';
X=repmat(x,1,N+1);
dX=X-X';
D=(c*(1./c)')./(dX+(eye(N+1)));
D=D-diag(sum(D'));
